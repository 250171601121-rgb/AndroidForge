#!/usr/bin/env bash
# One-command publish + build. Requires: git, GitHub CLI (gh), and `gh auth login` done once.
# Usage: ./push-and-build.sh [repo-name]   (default: tk-checker)
set -euo pipefail
REPO="${1:-tk-checker}"
[ -d .git ] || { git init -q -b main; }
git add -A
git -c user.name="${GIT_AUTHOR_NAME:-tk}" -c user.email="${GIT_AUTHOR_EMAIL:-tk@example.com}" commit -qm "TK CHECKER project" || true
gh repo view "$REPO" >/dev/null 2>&1 || gh repo create "$REPO" --private --source=. --remote=origin --push
git push -u origin main
echo "Waiting for workflow run..."; sleep 15
RUN_ID="$(gh run list --workflow build-apk.yml --limit 1 --json databaseId -q '.[0].databaseId')"
gh run watch "$RUN_ID" --exit-status || { gh run view "$RUN_ID" --log-failed > build-failure.log; echo "BUILD FAILED - send build-failure.log to Claude"; exit 1; }
mkdir -p dist && gh run download "$RUN_ID" -n tk-checker-debug-apk -D dist && gh run download "$RUN_ID" -n tk-checker-build-logs -D dist || true
( cd dist && sha256sum -c TK_CHECKER.apk.sha256 && ls -l TK_CHECKER.apk )
gh release view --json url -q .url
