package com.tk.checker.data.scanner

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AppOpsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.Process
import android.view.accessibility.AccessibilityManager
import com.tk.checker.domain.model.ConfidenceLevel
import com.tk.checker.domain.model.EvidenceAvailability
import com.tk.checker.domain.model.FindingSeverity
import com.tk.checker.domain.model.InjectionFinding
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.domain.model.UnavailableCheck
import java.io.File

/**
 * Universal Injection & Tampering Scanner.
 * Scans ALL accessible packages, active system services, native library directories,
 * APK integrity signals, and accessible storage scripts without hardcoding a single app.
 */
class InjectionScanner(private val context: Context? = null) {

    data class PackageInspectionInput(
        val packageName: String,
        val appName: String?,
        val isSystemApp: Boolean,
        val isDebuggable: Boolean,
        val isTestOnly: Boolean,
        val sourceDir: String?,
        val nativeLibraryFiles: List<String>,
        val installerPackage: String?,
        val hasOverlayGranted: Boolean,
        val hasAccessibilityEnabled: Boolean,
        val hasSigningMismatchOrUnsigned: Boolean
    )

    data class InjectionScanOutput(
        val status: ScanStatus,
        val findings: List<InjectionFinding>,
        val unavailableChecks: List<UnavailableCheck>,
        val inspectedPackageCount: Int
    )

    companion object {
        // Universal library/framework signature tokens (NOT limited to any single app)
        val SUSPICIOUS_NATIVE_LIB_PATTERNS = listOf(
            "frida",
            "gadget",
            "substrate",
            "xposed",
            "lsposed",
            "edxposed",
            "zygisk",
            "riru",
            "dobby",
            "whale",
            "sandhook",
            "pine",
            "modmenu",
            "injector",
            "cheat",
            "hack",
            "bypass"
        )

        val KNOWN_HOOKING_OR_TAMPER_PACKAGE_TOKENS = listOf(
            "xposed" to "Xposed / Hooking Framework",
            "lsposed" to "LSPosed Framework",
            "edxposed" to "EdXposed Framework",
            "frida" to "Frida Instrumentation Tool",
            "gameguardian" to "Memory Editor (GameGuardian)",
            "catch_.me_.if_.you_.can" to "Memory Editor Package",
            "luckypatcher" to "APK Patching Tool (Lucky Patcher)",
            "chelpus" to "APK Patching Framework",
            "virtualxposed" to "Virtual Hooking Container",
            "taichi" to "TaiChi Hooking Container",
            "modmenu" to "Game Mod Menu Component",
            "injector" to "Generic Injector Package"
        )

        val SUSPICIOUS_SCRIPT_EXTENSIONS = setOf("lua", "so", "dex", "sh")

        /**
         * Pure inspection logic shared between Android runtime and unit tests.
         * Never flags ordinary non-system apps solely for having normal permissions.
         */
        fun analyzePackages(
            packages: List<PackageInspectionInput>,
            storageFiles: List<File> = emptyList(),
            nowMillis: Long = System.currentTimeMillis()
        ): List<InjectionFinding> {
            val findings = mutableListOf<InjectionFinding>()

            for (pkg in packages) {
                val lowerPkg = pkg.packageName.lowercase()
                val lowerName = pkg.appName.orEmpty().lowercase()

                // 1. Hooking / Memory / Patching Framework detection
                val matchedFramework = KNOWN_HOOKING_OR_TAMPER_PACKAGE_TOKENS.firstOrNull { (token, _) ->
                    lowerPkg.contains(token) || lowerName.contains(token)
                }
                if (matchedFramework != null) {
                    findings += InjectionFinding(
                        id = "inj_pkg_${pkg.packageName}",
                        detectionName = matchedFramework.second,
                        appName = pkg.appName,
                        packageName = pkg.packageName,
                        evidenceSource = "Installed Package Registry",
                        evidenceDetails = "Package identifier or app label matches known hooking/tampering pattern '${matchedFramework.first}'.",
                        severity = FindingSeverity.HIGH,
                        confidence = ConfidenceLevel.HIGH,
                        timestampMillis = nowMillis,
                        availabilityStatus = EvidenceAvailability.INSTALLED,
                        isConfirmedInjection = true
                    )
                }

                // 2. Suspicious native library inspection (.so)
                val suspiciousLibs = pkg.nativeLibraryFiles.filter { libName ->
                    val l = libName.lowercase()
                    SUSPICIOUS_NATIVE_LIB_PATTERNS.any { pattern -> l.contains(pattern) }
                }
                if (suspiciousLibs.isNotEmpty()) {
                    findings += InjectionFinding(
                        id = "inj_lib_${pkg.packageName}",
                        detectionName = "Suspicious Native Library (.so)",
                        appName = pkg.appName,
                        packageName = pkg.packageName,
                        evidenceSource = "Native Library Directory",
                        evidenceDetails = "Detected suspicious native libraries: ${suspiciousLibs.joinToString(", ")}",
                        severity = FindingSeverity.CRITICAL,
                        confidence = ConfidenceLevel.HIGH,
                        timestampMillis = nowMillis,
                        availabilityStatus = EvidenceAvailability.INSTALLED,
                        isConfirmedInjection = true
                    )
                }

                // 3. Signature / Integrity anomalies on non-system apps
                if (!pkg.isSystemApp && pkg.hasSigningMismatchOrUnsigned) {
                    findings += InjectionFinding(
                        id = "inj_sig_${pkg.packageName}",
                        detectionName = "APK Signature Anomaly",
                        appName = pkg.appName,
                        packageName = pkg.packageName,
                        evidenceSource = "PackageManager SigningInfo",
                        evidenceDetails = "Package lacks valid verified signing certificates or exhibits signing lineage anomaly.",
                        severity = FindingSeverity.HIGH,
                        confidence = ConfidenceLevel.MEDIUM,
                        timestampMillis = nowMillis,
                        availabilityStatus = EvidenceAvailability.INSTALLED,
                        isConfirmedInjection = false
                    )
                }

                // 4. Non-system debuggable or testOnly sideloaded APK indicator
                val isSideloaded = pkg.installerPackage == null ||
                    pkg.installerPackage !in setOf(
                        "com.android.vending",
                        "com.google.android.packageinstaller",
                        "com.samsung.android.packageinstaller"
                    )
                if (!pkg.isSystemApp && pkg.isDebuggable) {
                    findings += InjectionFinding(
                        id = "inj_dbg_${pkg.packageName}",
                        detectionName = "Debuggable Non-System APK",
                        appName = pkg.appName,
                        packageName = pkg.packageName,
                        evidenceSource = "ApplicationInfo.FLAG_DEBUGGABLE",
                        evidenceDetails = "App carries FLAG_DEBUGGABLE (installer=${pkg.installerPackage ?: "unknown/sideloaded"}), enabling JDWP/native attach.",
                        severity = if (isSideloaded) FindingSeverity.MEDIUM else FindingSeverity.LOW,
                        confidence = ConfidenceLevel.HIGH,
                        timestampMillis = nowMillis,
                        availabilityStatus = EvidenceAvailability.INSTALLED,
                        isConfirmedInjection = false
                    )
                }

                // 5. Unexpected overlay + sideload / suspicious combination (avoid flagging normal Store apps)
                if (!pkg.isSystemApp && pkg.hasOverlayGranted && isSideloaded && pkg.hasAccessibilityEnabled) {
                    findings += InjectionFinding(
                        id = "inj_ovl_acc_${pkg.packageName}",
                        detectionName = "Sideloaded Overlay + Active Accessibility Service",
                        appName = pkg.appName,
                        packageName = pkg.packageName,
                        evidenceSource = "AppOpsManager + AccessibilityManager",
                        evidenceDetails = "Sideloaded app holds active SYSTEM_ALERT_WINDOW overlay and enabled AccessibilityService simultaneously.",
                        severity = FindingSeverity.HIGH,
                        confidence = ConfidenceLevel.MEDIUM,
                        timestampMillis = nowMillis,
                        availabilityStatus = EvidenceAvailability.INSTALLED,
                        isConfirmedInjection = false
                    )
                } else if (!pkg.isSystemApp && pkg.hasOverlayGranted && matchedFramework != null) {
                    findings += InjectionFinding(
                        id = "inj_ovl_${pkg.packageName}",
                        detectionName = "Tamper Tool Overlay Active",
                        appName = pkg.appName,
                        packageName = pkg.packageName,
                        evidenceSource = "AppOpsManager (SYSTEM_ALERT_WINDOW)",
                        evidenceDetails = "Overlay permission granted to flagged modification/tamper package.",
                        severity = FindingSeverity.HIGH,
                        confidence = ConfidenceLevel.HIGH,
                        timestampMillis = nowMillis,
                        availabilityStatus = EvidenceAvailability.INSTALLED,
                        isConfirmedInjection = true
                    )
                }

                // 6. Unexpected APK location outside standard /data/app or /system or /vendor or /product
                val src = pkg.sourceDir.orEmpty()
                if (src.isNotEmpty() &&
                    !src.startsWith("/data/app") &&
                    !src.startsWith("/system") &&
                    !src.startsWith("/vendor") &&
                    !src.startsWith("/product") &&
                    !src.startsWith("/apex") &&
                    !src.startsWith("/system_ext")
                ) {
                    findings += InjectionFinding(
                        id = "inj_src_${pkg.packageName}",
                        detectionName = "Non-Standard APK Install Path",
                        appName = pkg.appName,
                        packageName = pkg.packageName,
                        evidenceSource = "ApplicationInfo.sourceDir",
                        evidenceDetails = "APK loaded from non-standard path: $src",
                        severity = FindingSeverity.MEDIUM,
                        confidence = ConfidenceLevel.MEDIUM,
                        timestampMillis = nowMillis,
                        availabilityStatus = EvidenceAvailability.INSTALLED,
                        isConfirmedInjection = false
                    )
                }
            }

            // 7. Accessible storage suspicious scripts / libraries
            for (file in storageFiles) {
                val ext = file.extension.lowercase()
                val nameLower = file.name.lowercase()
                if (ext in SUSPICIOUS_SCRIPT_EXTENSIONS &&
                    SUSPICIOUS_NATIVE_LIB_PATTERNS.any { nameLower.contains(it) }
                ) {
                    findings += InjectionFinding(
                        id = "inj_file_${file.absolutePath.hashCode()}",
                        detectionName = "Suspicious External Script / Native Binary",
                        appName = null,
                        packageName = "shared.storage.artifact",
                        evidenceSource = "Accessible Shared Storage",
                        evidenceDetails = "Found file '${file.name}' (${file.length()} bytes) at ${file.absolutePath}",
                        severity = FindingSeverity.MEDIUM,
                        confidence = ConfidenceLevel.MEDIUM,
                        timestampMillis = file.lastModified().takeIf { it > 0 } ?: nowMillis,
                        availabilityStatus = EvidenceAvailability.STORED_ARTIFACT,
                        isConfirmedInjection = false
                    )
                }
            }

            return findings.sortedByDescending { it.severity.ordinal }
        }

        fun determineOverallStatus(
            findings: List<InjectionFinding>,
            unavailableChecks: List<UnavailableCheck>,
            inspectedPackageCount: Int
        ): ScanStatus {
            if (inspectedPackageCount == 0 && unavailableChecks.isNotEmpty()) {
                return ScanStatus.UNAVAILABLE
            }
            if (findings.any { it.isConfirmedInjection || it.severity >= FindingSeverity.HIGH }) {
                return ScanStatus.DETECTED
            }
            if (findings.isNotEmpty()) {
                return ScanStatus.WARNING
            }
            if (unavailableChecks.isNotEmpty()) {
                return ScanStatus.WARNING
            }
            return ScanStatus.CLEAN
        }
    }

    fun scan(): InjectionScanOutput {
        val ctx = context ?: return InjectionScanOutput(
            status = ScanStatus.UNAVAILABLE,
            findings = emptyList(),
            unavailableChecks = listOf(
                UnavailableCheck(
                    checkName = "Installed Package & Service Inspection",
                    category = "Injection Scanner",
                    reason = "Android Context unavailable"
                )
            ),
            inspectedPackageCount = 0
        )

        val now = System.currentTimeMillis()
        val unavailable = mutableListOf<UnavailableCheck>()
        val pm = ctx.packageManager

        val enabledAccessibilityPackages = runCatching {
            val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
            am?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                ?.mapNotNull { it.resolveInfo?.serviceInfo?.packageName }
                ?.toSet() ?: emptySet()
        }.getOrElse {
            unavailable += UnavailableCheck(
                checkName = "Active Accessibility Services",
                category = "Injection Scanner",
                reason = "Unable to query AccessibilityManager: ${it.message}"
            )
            emptySet()
        }

        val installedPackages: List<PackageInfo> = runCatching {
            val flags = PackageManager.GET_META_DATA or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    PackageManager.GET_SIGNING_CERTIFICATES
                } else {
                    @Suppress("DEPRECATION")
                    PackageManager.GET_SIGNATURES
                }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(flags)
            }
        }.getOrElse {
            unavailable += UnavailableCheck(
                checkName = "Installed Package Enumeration",
                category = "Injection Scanner",
                reason = "PackageManager blocked package enumeration: ${it.message}"
            )
            emptyList()
        }

        val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager

        val inputs = installedPackages.mapNotNull { pkgInfo ->
            val appInfo = pkgInfo.applicationInfo ?: return@mapNotNull null
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val isDebuggable = (appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
            val isTestOnly = (appInfo.flags and ApplicationInfo.FLAG_TEST_ONLY) != 0
            val label = runCatching { pm.getApplicationLabel(appInfo).toString() }.getOrNull()

            val nativeLibs = runCatching {
                val dir = appInfo.nativeLibraryDir?.let { File(it) }
                if (dir != null && dir.exists() && dir.canRead()) {
                    dir.listFiles()?.map { it.name } ?: emptyList()
                } else {
                    emptyList()
                }
            }.getOrDefault(emptyList())

            val installer = runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    pm.getInstallSourceInfo(pkgInfo.packageName).installingPackageName
                } else {
                    @Suppress("DEPRECATION")
                    pm.getInstallerPackageName(pkgInfo.packageName)
                }
            }.getOrNull()

            val overlayGranted = runCatching {
                if (appOps == null) false
                else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    appOps.unsafeCheckOpNoThrow(
                        AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW,
                        appInfo.uid,
                        pkgInfo.packageName
                    ) == AppOpsManager.MODE_ALLOWED
                } else {
                    @Suppress("DEPRECATION")
                    appOps.checkOpNoThrow(
                        AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW,
                        appInfo.uid,
                        pkgInfo.packageName
                    ) == AppOpsManager.MODE_ALLOWED
                }
            }.getOrDefault(false)

            val sigAnomaly = runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val signingInfo = pkgInfo.signingInfo
                    signingInfo == null || signingInfo.apkContentsSigners.isNullOrEmpty()
                } else {
                    @Suppress("DEPRECATION")
                    pkgInfo.signatures.isNullOrEmpty()
                }
            }.getOrDefault(false)

            PackageInspectionInput(
                packageName = pkgInfo.packageName,
                appName = label,
                isSystemApp = isSystem,
                isDebuggable = isDebuggable,
                isTestOnly = isTestOnly,
                sourceDir = appInfo.sourceDir,
                nativeLibraryFiles = nativeLibs,
                installerPackage = installer,
                hasOverlayGranted = overlayGranted,
                hasAccessibilityEnabled = pkgInfo.packageName in enabledAccessibilityPackages,
                hasSigningMismatchOrUnsigned = sigAnomaly
            )
        }

        // Scan accessible external Download/Documents for suspicious scripts/libs
        val storageArtifacts = mutableListOf<File>()
        val dirsToCheck = listOfNotNull(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        )
        var storageReadable = false
        for (dir in dirsToCheck) {
            if (dir.exists() && dir.canRead()) {
                storageReadable = true
                dir.listFiles()?.take(200)?.forEach { f ->
                    if (f.isFile) storageArtifacts += f
                }
            }
        }
        if (!storageReadable) {
            unavailable += UnavailableCheck(
                checkName = "Shared Storage Script Scan (Downloads/Documents)",
                category = "Injection Scanner",
                reason = "Scoped storage on Android 11+ restricts direct reading of non-media files without explicit permission.",
                requiredAction = "Grant storage folder access in App Trace Scanner or Settings if desired."
            )
        }

        // Memory/process injection of other apps is protected by Android SELinux sandbox
        unavailable += UnavailableCheck(
            checkName = "Cross-App Runtime Memory Inspection (/proc/<pid>/maps)",
            category = "Injection Scanner",
            reason = "Android app sandbox and SELinux block non-root apps from reading other applications' process memory."
        )

        val findings = analyzePackages(inputs, storageArtifacts, now)
        val status = determineOverallStatus(findings, unavailable, inputs.size)

        return InjectionScanOutput(
            status = status,
            findings = findings,
            unavailableChecks = unavailable,
            inspectedPackageCount = inputs.size
        )
    }
}
