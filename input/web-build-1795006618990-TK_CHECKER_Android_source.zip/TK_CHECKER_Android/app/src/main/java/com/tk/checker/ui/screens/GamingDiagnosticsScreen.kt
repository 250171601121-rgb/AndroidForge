package com.tk.checker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.ui.components.StatusPill
import com.tk.checker.ui.components.TkKeyValueRow
import com.tk.checker.ui.components.TkSectionCard
import com.tk.checker.ui.components.statusColor
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.TkUiState

@Composable
fun GamingDiagnosticsScreen(
    uiState: TkUiState,
    onRunScan: () -> Unit
) {
    val g = uiState.currentReport?.gamingDiagnostics

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TkColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TkSectionCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("GAMING HARDWARE & NETWORK", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                    StatusPill(status = g?.status ?: ScanStatus.UNKNOWN)
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onRunScan,
                    enabled = !uiState.isScanning,
                    colors = ButtonDefaults.buttonColors(containerColor = TkColors.NeonBlue, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (uiState.isScanning) "BENCHMARKING..." else "REFRESH DIAGNOSTICS")
                }
            }
        }

        if (g == null) {
            item {
                TkSectionCard {
                    Text("Tap REFRESH DIAGNOSTICS to inspect CPU, GPU, RAM, storage, display Hz, thermal state, and ping.", style = MaterialTheme.typography.bodyMedium)
                }
            }
            return@LazyColumn
        }

        item {
            TkSectionCard {
                Text("PROCESSOR & GRAPHICS", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonPurple)
                Spacer(Modifier.height(8.dp))
                TkKeyValueRow("CPU / SoC", g.cpuModel)
                TkKeyValueRow("CPU Cores", "${g.cpuCores} cores")
                TkKeyValueRow("Max Clock", g.cpuMaxFreqMhz?.let { "$it MHz" } ?: "UNAVAILABLE")
                TkKeyValueRow("ABIs", g.cpuAbis.joinToString(", "))
                TkKeyValueRow("GPU Renderer", g.gpuRenderer)
                TkKeyValueRow("GPU Vendor", g.gpuVendor)
                TkKeyValueRow("OpenGL ES", g.glEsVersion)
            }
        }

        item {
            TkSectionCard {
                Text("MEMORY, STORAGE & DISPLAY", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                Spacer(Modifier.height(8.dp))
                TkKeyValueRow("Total RAM", "${g.totalRamMb} MB")
                TkKeyValueRow("Available RAM", "${g.availableRamMb} MB")
                TkKeyValueRow("Total Storage", "${g.totalStorageGb} GB")
                TkKeyValueRow("Available Storage", "${g.availableStorageGb} GB")
                TkKeyValueRow("Resolution", "${g.screenWidthPx} x ${g.screenHeightPx}")
                TkKeyValueRow("Active Refresh Rate", "${g.refreshRateHz.toInt()} Hz")
                TkKeyValueRow("Supported Rates", g.supportedRefreshRates.joinToString { "${it.toInt()}Hz" })
                TkKeyValueRow("Android Version", "Android ${g.androidVersion} (API ${g.sdkInt})")
            }
        }

        item {
            TkSectionCard {
                Text("BATTERY, THERMAL & FPS", style = MaterialTheme.typography.labelMedium, color = TkColors.WarningAmber)
                Spacer(Modifier.height(8.dp))
                TkKeyValueRow("Battery Level", if (g.batteryLevelPercent >= 0) "${g.batteryLevelPercent}%" else "UNAVAILABLE")
                TkKeyValueRow("Battery Temp", g.batteryTempCelsius?.let { "$it °C" } ?: "UNAVAILABLE")
                TkKeyValueRow("Charging", if (g.isCharging) "Yes" else "No")
                TkKeyValueRow("Thermal State", g.thermalStatusLabel, valueColor = if (g.thermalAvailable) TkColors.TextPrimary else TkColors.UnavailableSlate)
                TkKeyValueRow(
                    "FPS Monitor",
                    if (g.fpsMeasurement.available) "${g.fpsMeasurement.valueFps} FPS" else "FPS MONITORING UNAVAILABLE",
                    valueColor = statusColor(g.fpsMeasurement.status)
                )
                Spacer(Modifier.height(4.dp))
                Text(g.fpsMeasurement.scopeDescription, style = MaterialTheme.typography.bodyMedium)
            }
        }

        item {
            TkSectionCard(borderColor = statusColor(g.network.status).copy(alpha = 0.4f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("NETWORK LATENCY DIAGNOSTICS", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                    StatusPill(status = g.network.status)
                }
                Spacer(Modifier.height(8.dp))
                TkKeyValueRow("Internet", if (g.network.connected) "Connected (${g.network.transportType})" else "Offline")
                TkKeyValueRow("Ping (Avg RTT)", g.network.pingMs?.let { "$it ms" } ?: "UNAVAILABLE")
                TkKeyValueRow("Jitter", g.network.jitterMs?.let { "$it ms" } ?: "UNAVAILABLE")
                TkKeyValueRow("Packet Loss", g.network.packetLossPercent?.let { "$it%" } ?: "UNAVAILABLE")
                TkKeyValueRow("Stability", g.network.stabilityLabel, valueColor = statusColor(g.network.status))
                Spacer(Modifier.height(4.dp))
                Text(g.network.details, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
