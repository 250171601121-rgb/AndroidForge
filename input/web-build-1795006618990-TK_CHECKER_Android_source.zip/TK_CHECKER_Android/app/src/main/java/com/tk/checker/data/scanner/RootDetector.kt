package com.tk.checker.data.scanner

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.tk.checker.domain.model.RootAssessment
import com.tk.checker.domain.model.RootSignal
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.domain.model.SignalStrength
import java.io.File

/**
 * Multi-signal, conservative Root Detector.
 * Rule: Never classify a device as rooted based on a single weak indicator.
 */
class RootDetector(private val context: Context? = null) {

    companion object {
        val SU_BINARY_PATHS = listOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/vendor/bin/su",
            "/su/bin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/apex/com.android.runtime/bin/su"
        )

        val ROOT_MANAGEMENT_PACKAGES = listOf(
            "com.topjohnwu.magisk" to "Magisk Manager",
            "me.weishu.kernelsu" to "KernelSU",
            "me.bmax.apatch" to "APatch",
            "eu.chainfire.supersu" to "SuperSU",
            "com.noshufou.android.su" to "Superuser",
            "com.koushikdutta.superuser" to "ClockworkMod Superuser",
            "com.kingroot.kinguser" to "KingRoot",
            "com.kingoapp.root" to "KingoRoot",
            "com.zhiqupk.root.global" to "Root Master"
        )

        val ROOT_ARTIFACT_PATHS = listOf(
            "/system/app/Superuser.apk",
            "/system/etc/init.d",
            "/data/adb/magisk",
            "/data/adb/ksu",
            "/data/adb/apatch",
            "/data/adb/modules",
            "/sbin/.magisk"
        )

        /**
         * Pure evaluation function so unit tests can verify multi-signal rules deterministically.
         */
        fun evaluateSignals(signals: List<RootSignal>, checkedAtMillis: Long): RootAssessment {
            val accessibleSignals = signals.filter { it.accessible }
            if (accessibleSignals.isEmpty()) {
                return RootAssessment(
                    status = ScanStatus.UNAVAILABLE,
                    isRooted = false,
                    summary = "Root verification unavailable",
                    explanation = "All root indicator probes were blocked by the OS environment.",
                    strongMatches = 0,
                    weakMatches = 0,
                    signals = signals,
                    rootCommandAvailable = false,
                    checkedAtMillis = checkedAtMillis
                )
            }

            val strongMatches = accessibleSignals.count {
                it.matched && it.strength == SignalStrength.STRONG
            }
            val moderateMatches = accessibleSignals.count {
                it.matched && it.strength == SignalStrength.MODERATE
            }
            val weakMatches = accessibleSignals.count {
                it.matched && it.strength == SignalStrength.WEAK
            }

            val suPresent = accessibleSignals.any { it.id == "su_binary" && it.matched }

            val (status, isRooted, summary, explanation) = when {
                strongMatches >= 2 || (suPresent && (moderateMatches >= 1 || weakMatches >= 1)) -> {
                    Quad(
                        ScanStatus.DETECTED,
                        true,
                        "Root indicators confirmed ($strongMatches strong, $moderateMatches moderate)",
                        "Multiple independent root artifacts were observed (su binary, root manager, or root mount/system state)."
                    )
                }
                strongMatches == 1 -> {
                    Quad(
                        ScanStatus.WARNING,
                        false,
                        "Single strong root indicator observed",
                        "One strong indicator matched without corroborating evidence. Confirm in Root Panel before treating device as rooted."
                    )
                }
                moderateMatches >= 2 -> {
                    Quad(
                        ScanStatus.DETECTED,
                        true,
                        "Multiple root system modifications detected",
                        "Corroborating moderate root indicators (e.g., SELinux permissive + mount artifacts) were observed."
                    )
                }
                moderateMatches == 1 || weakMatches >= 1 -> {
                    Quad(
                        ScanStatus.WARNING,
                        false,
                        "Weak or isolated indicator observed",
                        "A single weak/moderate signal (such as test-keys or custom build prop) does not prove root access on its own."
                    )
                }
                else -> {
                    Quad(
                        ScanStatus.CLEAN,
                        false,
                        "No root indicators detected",
                        "Checked standard su paths, root managers, build tags, mount table, and SELinux state with zero matches."
                    )
                }
            }

            return RootAssessment(
                status = status,
                isRooted = isRooted,
                summary = summary,
                explanation = explanation,
                strongMatches = strongMatches,
                weakMatches = weakMatches,
                signals = signals,
                rootCommandAvailable = suPresent,
                checkedAtMillis = checkedAtMillis
            )
        }

        private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
    }

    fun detect(): RootAssessment {
        val now = System.currentTimeMillis()
        val signals = mutableListOf<RootSignal>()

        // 1. Check su binary existence (non-invasive stat check; does not execute su)
        val foundSuPaths = SU_BINARY_PATHS.filter { path ->
            runCatching { File(path).exists() }.getOrDefault(false)
        }
        signals += RootSignal(
            id = "su_binary",
            name = "SU Binary Check",
            strength = SignalStrength.STRONG,
            matched = foundSuPaths.isNotEmpty(),
            accessible = true,
            evidenceSource = "Filesystem Path Inspection",
            details = if (foundSuPaths.isNotEmpty()) {
                "Found su binary at: ${foundSuPaths.joinToString(", ")}"
            } else {
                "No su binary found across ${SU_BINARY_PATHS.size} standard paths"
            }
        )

        // 2. Check PATH for su binary
        val pathEnv = System.getenv("PATH").orEmpty()
        val pathSu = pathEnv.split(":").filter { it.isNotBlank() }.mapNotNull { dir ->
            val f = File(dir, "su")
            if (runCatching { f.exists() }.getOrDefault(false)) f.absolutePath else null
        }
        signals += RootSignal(
            id = "path_su",
            name = "PATH SU Executable Check",
            strength = SignalStrength.STRONG,
            matched = pathSu.isNotEmpty(),
            accessible = pathEnv.isNotBlank(),
            evidenceSource = "Environment PATH",
            details = if (pathSu.isNotEmpty()) {
                "Found su in PATH: ${pathSu.joinToString(", ")}"
            } else {
                "No su binary found in shell PATH"
            }
        )

        // 3. Check root management applications
        val pm = context?.packageManager
        if (pm != null) {
            val detectedManagers = ROOT_MANAGEMENT_PACKAGES.mapNotNull { (pkg, label) ->
                val installed = runCatching {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.getPackageInfo(pkg, 0)
                    }
                    true
                }.getOrDefault(false)
                if (installed) "$label ($pkg)" else null
            }
            signals += RootSignal(
                id = "root_managers",
                name = "Root Management Apps",
                strength = SignalStrength.STRONG,
                matched = detectedManagers.isNotEmpty(),
                accessible = true,
                evidenceSource = "PackageManager",
                details = if (detectedManagers.isNotEmpty()) {
                    "Detected installed root manager(s): ${detectedManagers.joinToString(", ")}"
                } else {
                    "No known root management packages detected"
                }
            )
        } else {
            signals += RootSignal(
                id = "root_managers",
                name = "Root Management Apps",
                strength = SignalStrength.STRONG,
                matched = false,
                accessible = false,
                evidenceSource = "PackageManager",
                details = "PackageManager unavailable in current context"
            )
        }

        // 4. Build.TAGS test-keys check (Weak indicator on its own)
        val buildTags = Build.TAGS.orEmpty()
        val hasTestKeys = buildTags.contains("test-keys", ignoreCase = true)
        signals += RootSignal(
            id = "test_keys",
            name = "Build Tags (test-keys)",
            strength = SignalStrength.WEAK,
            matched = hasTestKeys,
            accessible = true,
            evidenceSource = "android.os.Build.TAGS",
            details = if (hasTestKeys) {
                "Build.TAGS contains 'test-keys' ($buildTags) — weak indicator only"
            } else {
                "Build.TAGS reports '$buildTags'"
            }
        )

        // 5. Known root artifact paths
        val foundArtifacts = ROOT_ARTIFACT_PATHS.filter { path ->
            runCatching { File(path).exists() }.getOrDefault(false)
        }
        signals += RootSignal(
            id = "root_files",
            name = "Root Files & Directories",
            strength = SignalStrength.STRONG,
            matched = foundArtifacts.isNotEmpty(),
            accessible = true,
            evidenceSource = "Filesystem Artifact Check",
            details = if (foundArtifacts.isNotEmpty()) {
                "Accessible root artifacts: ${foundArtifacts.joinToString(", ")}"
            } else {
                "No known root artifact files visible to app sandbox"
            }
        )

        // 6. /proc/mounts inspection for Magisk / KernelSU / overlayfs artifacts
        val mountCheck = readProcMounts()
        signals += mountCheck

        // 7. SELinux enforce status
        signals += checkSelinuxState()

        // 8. System debuggable property (ro.debuggable / ro.secure)
        signals += checkSystemProps()

        return evaluateSignals(signals, now)
    }

    private fun readProcMounts(): RootSignal {
        return runCatching {
            val file = File("/proc/mounts")
            if (!file.canRead()) {
                return RootSignal(
                    id = "proc_mounts",
                    name = "Mount Table Inspection",
                    strength = SignalStrength.MODERATE,
                    matched = false,
                    accessible = false,
                    evidenceSource = "/proc/mounts",
                    details = "UNAVAILABLE: /proc/mounts cannot be read in this sandbox"
                )
            }
            val suspiciousLines = file.readLines().filter { line ->
                val lower = line.lowercase()
                lower.contains("magisk") ||
                    lower.contains("kernelsu") ||
                    lower.contains("ksu") ||
                    lower.contains("apatch") ||
                    lower.contains("zygisk")
            }
            RootSignal(
                id = "proc_mounts",
                name = "Mount Table Inspection",
                strength = SignalStrength.MODERATE,
                matched = suspiciousLines.isNotEmpty(),
                accessible = true,
                evidenceSource = "/proc/mounts",
                details = if (suspiciousLines.isNotEmpty()) {
                    "Observed ${suspiciousLines.size} root-related mount entry/entries"
                } else {
                    "No Magisk/KernelSU/Zygisk mounts observed in /proc/mounts"
                }
            )
        }.getOrElse {
            RootSignal(
                id = "proc_mounts",
                name = "Mount Table Inspection",
                strength = SignalStrength.MODERATE,
                matched = false,
                accessible = false,
                evidenceSource = "/proc/mounts",
                details = "UNAVAILABLE: ${it.message ?: "Access denied"}"
            )
        }
    }

    private fun checkSelinuxState(): RootSignal {
        return runCatching {
            val enforceFile = File("/sys/fs/selinux/enforce")
            if (!enforceFile.canRead()) {
                return RootSignal(
                    id = "selinux_state",
                    name = "SELinux Enforcement",
                    strength = SignalStrength.MODERATE,
                    matched = false,
                    accessible = false,
                    evidenceSource = "/sys/fs/selinux/enforce",
                    details = "UNAVAILABLE: Restricted by SELinux policy on unprivileged apps"
                )
            }
            val value = enforceFile.readText().trim()
            val permissive = value == "0"
            RootSignal(
                id = "selinux_state",
                name = "SELinux Enforcement",
                strength = SignalStrength.MODERATE,
                matched = permissive,
                accessible = true,
                evidenceSource = "/sys/fs/selinux/enforce",
                details = if (permissive) {
                    "SELinux is in Permissive mode (0)"
                } else {
                    "SELinux is Enforcing (1)"
                }
            )
        }.getOrElse {
            RootSignal(
                id = "selinux_state",
                name = "SELinux Enforcement",
                strength = SignalStrength.MODERATE,
                matched = false,
                accessible = false,
                evidenceSource = "/sys/fs/selinux/enforce",
                details = "UNAVAILABLE: SELinux status blocked"
            )
        }
    }

    private fun checkSystemProps(): RootSignal {
        return runCatching {
            val process = ProcessBuilder("getprop", "ro.debuggable").start()
            val debuggable = process.inputStream.bufferedReader().readText().trim()
            val secureProc = ProcessBuilder("getprop", "ro.secure").start()
            val secure = secureProc.inputStream.bufferedReader().readText().trim()
            val isDebug = debuggable == "1" || secure == "0"
            RootSignal(
                id = "sys_props",
                name = "System Boot Properties",
                strength = SignalStrength.WEAK,
                matched = isDebug,
                accessible = debuggable.isNotEmpty() || secure.isNotEmpty(),
                evidenceSource = "getprop (ro.debuggable, ro.secure)",
                details = "ro.debuggable=${debuggable.ifEmpty { "unknown" }}, ro.secure=${secure.ifEmpty { "unknown" }}"
            )
        }.getOrElse {
            RootSignal(
                id = "sys_props",
                name = "System Boot Properties",
                strength = SignalStrength.WEAK,
                matched = false,
                accessible = false,
                evidenceSource = "getprop",
                details = "UNAVAILABLE: Unable to query system properties"
            )
        }
    }
}
