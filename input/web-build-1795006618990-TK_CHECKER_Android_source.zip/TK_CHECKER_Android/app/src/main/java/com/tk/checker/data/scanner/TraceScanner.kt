package com.tk.checker.data.scanner

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Process
import android.provider.DocumentsContract
import com.tk.checker.domain.model.AppTraceFinding
import com.tk.checker.domain.model.ConfidenceLevel
import com.tk.checker.domain.model.EvidenceAvailability
import com.tk.checker.domain.model.InjectionFinding
import com.tk.checker.domain.model.RootCommandResult
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.domain.model.UnavailableCheck
import java.io.File

/**
 * Universal Deleted & Historical Application Trace Scanner.
 * Searches legitimate, accessible evidence sources without limiting detection
 * to any single application name.
 */
class TraceScanner(private val context: Context? = null) {

    data class RawTraceEvidence(
        val key: String,
        val appName: String?,
        val packageName: String?,
        val evidenceSource: String,
        val evidenceDetails: String,
        val location: String,
        val lastModifiedMillis: Long?,
        val confidence: ConfidenceLevel,
        val isPackageScoped: Boolean
    )

    data class TraceScanOutput(
        val status: ScanStatus,
        val traces: List<AppTraceFinding>,
        val unavailableChecks: List<UnavailableCheck>,
        val accessibleSourcesCount: Int
    )

    companion object {
        private val STANDARD_PUBLIC_DIRS = setOf(
            "alarms", "android", "audiobooks", "dcim", "documents",
            "download", "downloads", "movies", "music", "notifications",
            "pictures", "podcasts", "recordings", "ringtones", "lost.dir",
            ".thumbnails", ".trash", "system"
        )

        private val PACKAGE_NAME_REGEX = Regex("^[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+$")

        fun isValidPackageLikeName(name: String): Boolean = PACKAGE_NAME_REGEX.matches(name)

        /**
         * Derives a clean, non-fabricated app label ONLY when package or APK metadata supports it.
         */
        fun deriveAppLabelFromPackage(packageName: String): String? {
            if (!isValidPackageLikeName(packageName)) return null
            val lastSegment = packageName.substringAfterLast('.')
                .replace('_', ' ')
                .trim()
            if (lastSegment.length < 2) return null
            return lastSegment.replaceFirstChar { it.uppercaseChar() }
        }

        /**
         * Deduplicates and aggregates raw evidence records into verified per-app traces.
         * Never counts duplicate files inside the same folder as separate traces,
         * and separates historical traces from confirmed injection findings.
         */
        fun aggregateEvidence(
            rawEvidence: List<RawTraceEvidence>,
            installedPackages: Map<String, String?>,
            injectionFindings: List<InjectionFinding>
        ): List<AppTraceFinding> {
            val grouped = rawEvidence.groupBy { it.key.lowercase() }

            return grouped.values.map { records ->
                val primary = records.maxByOrNull { it.confidence.ordinal } ?: records.first()
                val pkg = records.firstNotNullOfOrNull { it.packageName }
                val isInstalled = pkg != null && installedPackages.containsKey(pkg)
                val resolvedName = pkg?.let { installedPackages[it] }
                    ?: records.firstNotNullOfOrNull { it.appName }
                    ?: pkg?.let { deriveAppLabelFromPackage(it) }

                val distinctSources = records.map { "${it.evidenceSource}:${it.location}" }.distinct()
                val locations = records.map { it.location }.distinct()
                val latestModified = records.mapNotNull { it.lastModifiedMillis }.maxOrNull()

                val highestConfidence = when {
                    distinctSources.size >= 2 -> ConfidenceLevel.HIGH
                    else -> records.maxOf { it.confidence }
                }

                val relatedInjections = injectionFindings.filter { inj ->
                    (pkg != null && inj.packageName.equals(pkg, ignoreCase = true)) ||
                        (resolvedName != null && inj.appName?.equals(resolvedName, ignoreCase = true) == true)
                }

                val confirmedInj = relatedInjections.any { it.isConfirmedInjection }
                val suspiciousInj = relatedInjections.isNotEmpty()
                val injNote = when {
                    confirmedInj -> "CONFIRMED (${relatedInjections.size} injection finding(s))"
                    suspiciousInj -> "SUSPICIOUS INDICATORS (${relatedInjections.size} non-confirmed)"
                    else -> "NOT CONFIRMED"
                }

                AppTraceFinding(
                    id = "trace_${primary.key.lowercase().hashCode()}",
                    appName = resolvedName,
                    packageName = pkg,
                    status = if (isInstalled) EvidenceAvailability.INSTALLED else EvidenceAvailability.UNINSTALLED,
                    verifiedTraceCount = distinctSources.size,
                    evidenceSource = records.map { it.evidenceSource }.distinct().joinToString(" + "),
                    evidenceDetails = records.map { it.evidenceDetails }.distinct().joinToString(" | "),
                    locations = locations,
                    lastModifiedMillis = latestModified,
                    confidence = highestConfidence,
                    suspiciousInjectionFound = suspiciousInj,
                    injectionNote = injNote
                )
            }.sortedWith(
                compareBy<AppTraceFinding> { it.status == EvidenceAvailability.INSTALLED }
                    .thenByDescending { it.confidence.ordinal }
                    .thenByDescending { it.lastModifiedMillis ?: 0L }
            )
        }

        fun determineTraceStatus(
            traces: List<AppTraceFinding>,
            unavailableChecks: List<UnavailableCheck>,
            accessibleSourcesCount: Int
        ): ScanStatus {
            if (accessibleSourcesCount == 0 && unavailableChecks.isNotEmpty()) {
                return ScanStatus.UNAVAILABLE
            }
            val uninstalledCount = traces.count { it.status == EvidenceAvailability.UNINSTALLED }
            return when {
                uninstalledCount > 0 -> ScanStatus.WARNING
                unavailableChecks.isNotEmpty() -> ScanStatus.UNAVAILABLE
                else -> ScanStatus.CLEAN
            }
        }
    }

    fun hasUsageStatsPermission(): Boolean {
        val ctx = context ?: return false
        val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun scan(
        installedPackages: Map<String, String?>,
        injectionFindings: List<InjectionFinding>,
        safTreeUriString: String? = null,
        rootCommandResults: List<RootCommandResult> = emptyList()
    ): TraceScanOutput {
        val ctx = context ?: return TraceScanOutput(
            status = ScanStatus.UNAVAILABLE,
            traces = emptyList(),
            unavailableChecks = listOf(
                UnavailableCheck("Trace Scanner", "App Trace Scanner", "Android Context unavailable")
            ),
            accessibleSourcesCount = 0
        )

        val rawEvidence = mutableListOf<RawTraceEvidence>()
        val unavailable = mutableListOf<UnavailableCheck>()
        var accessibleSources = 0

        // 1. Direct Android/data and Android/obb (accessible on API 26-29 with storage perm; restricted on API 30+)
        val extRoot = runCatching { Environment.getExternalStorageDirectory() }.getOrNull()
        val androidDataDir = extRoot?.let { File(it, "Android/data") }
        val androidObbDir = extRoot?.let { File(it, "Android/obb") }

        var directAndroidDataReadable = false
        if (androidDataDir != null && androidDataDir.exists() && androidDataDir.canRead()) {
            val entries = androidDataDir.listFiles()?.filter { it.isDirectory }.orEmpty()
            if (entries.isNotEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                directAndroidDataReadable = true
                accessibleSources++
                entries.forEach { dir ->
                    if (isValidPackageLikeName(dir.name)) {
                        rawEvidence += RawTraceEvidence(
                            key = dir.name,
                            appName = installedPackages[dir.name] ?: deriveAppLabelFromPackage(dir.name),
                            packageName = dir.name,
                            evidenceSource = "Leftover Android/data folder",
                            evidenceDetails = "Application data directory '${dir.name}' present on external storage.",
                            location = dir.absolutePath,
                            lastModifiedMillis = dir.lastModified().takeIf { it > 0 },
                            confidence = ConfidenceLevel.HIGH,
                            isPackageScoped = true
                        )
                    }
                }
            }
        }
        if (!directAndroidDataReadable) {
            // Check if user granted SAF folder access
            val safUri = safTreeUriString?.let { runCatching { Uri.parse(it) }.getOrNull() }
            if (safUri != null) {
                val safCollected = readSafFolderTraces(ctx, safUri, installedPackages)
                if (safCollected.isNotEmpty()) {
                    accessibleSources++
                    rawEvidence += safCollected
                } else {
                    accessibleSources++
                }
            } else {
                unavailable += UnavailableCheck(
                    checkName = "Android/data & Android/obb Scoped Folder Scan",
                    category = "App Trace Scanner",
                    reason = "Android ${Build.VERSION.RELEASE} scoped storage blocks direct access to other apps' Android/data folders.",
                    requiredAction = "Use 'Grant Folder Access' on the App Trace Scanner screen if your OS version allows SAF directory selection."
                )
            }
        }

        if (androidObbDir != null && androidObbDir.exists() && androidObbDir.canRead()) {
            val obbEntries = androidObbDir.listFiles()?.filter { it.isDirectory }.orEmpty()
            if (obbEntries.isNotEmpty() || Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
                accessibleSources++
                obbEntries.forEach { dir ->
                    if (isValidPackageLikeName(dir.name)) {
                        rawEvidence += RawTraceEvidence(
                            key = dir.name,
                            appName = installedPackages[dir.name] ?: deriveAppLabelFromPackage(dir.name),
                            packageName = dir.name,
                            evidenceSource = "Leftover Android/obb folder",
                            evidenceDetails = "OBB expansion asset folder '${dir.name}' found.",
                            location = dir.absolutePath,
                            lastModifiedMillis = dir.lastModified().takeIf { it > 0 },
                            confidence = ConfidenceLevel.HIGH,
                            isPackageScoped = true
                        )
                    }
                }
            }
        }

        // 2. Shared Storage APK archives in Download / Documents
        val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (downloadDir != null && downloadDir.exists() && downloadDir.canRead()) {
            accessibleSources++
            val apkFiles = downloadDir.listFiles()?.filter {
                it.isFile && it.extension.equals("apk", ignoreCase = true)
            }.orEmpty()
            val pm = ctx.packageManager
            for (apk in apkFiles.take(100)) {
                val pkgArchive = runCatching {
                    @Suppress("DEPRECATION")
                    pm.getPackageArchiveInfo(apk.absolutePath, 0)
                }.getOrNull()
                if (pkgArchive != null) {
                    val pkgName = pkgArchive.packageName
                    val appLabel = pkgArchive.applicationInfo?.let {
                        it.sourceDir = apk.absolutePath
                        it.publicSourceDir = apk.absolutePath
                        runCatching { pm.getApplicationLabel(it).toString() }.getOrNull()
                    } ?: deriveAppLabelFromPackage(pkgName)
                    rawEvidence += RawTraceEvidence(
                        key = pkgName,
                        appName = appLabel,
                        packageName = pkgName,
                        evidenceSource = "Shared Storage APK Installer",
                        evidenceDetails = "Installer file '${apk.name}' (${apk.length() / 1024} KB) found in Downloads.",
                        location = apk.absolutePath,
                        lastModifiedMillis = apk.lastModified().takeIf { it > 0 },
                        confidence = ConfidenceLevel.HIGH,
                        isPackageScoped = true
                    )
                }
            }
        } else {
            unavailable += UnavailableCheck(
                checkName = "Shared Storage Download APK Scan",
                category = "App Trace Scanner",
                reason = "Direct read access to Download directory is restricted without storage permission."
            )
        }

        // 3. Top-level /sdcard non-standard package-named folders ONLY (never flag generic names)
        if (extRoot != null && extRoot.exists() && extRoot.canRead()) {
            val topDirs = extRoot.listFiles()?.filter { it.isDirectory }.orEmpty()
            if (topDirs.isNotEmpty()) {
                accessibleSources++
                topDirs.forEach { dir ->
                    val lower = dir.name.lowercase()
                    if (lower !in STANDARD_PUBLIC_DIRS && isValidPackageLikeName(dir.name)) {
                        rawEvidence += RawTraceEvidence(
                            key = dir.name,
                            appName = installedPackages[dir.name] ?: deriveAppLabelFromPackage(dir.name),
                            packageName = dir.name,
                            evidenceSource = "Shared Storage Application Folder",
                            evidenceDetails = "Package-named directory '${dir.name}' in shared storage root.",
                            location = dir.absolutePath,
                            lastModifiedMillis = dir.lastModified().takeIf { it > 0 },
                            confidence = ConfidenceLevel.MEDIUM,
                            isPackageScoped = true
                        )
                    }
                }
            }
        }

        // 4. UsageStatsManager (when explicitly permitted by user)
        if (hasUsageStatsPermission()) {
            accessibleSources++
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            val end = System.currentTimeMillis()
            val start = end - (30L * 24 * 60 * 60 * 1000) // 30 days
            val stats = runCatching {
                usm?.queryUsageStats(UsageStatsManager.INTERVAL_MONTHLY, start, end).orEmpty()
            }.getOrDefault(emptyList())

            stats.filter { it.lastTimeUsed > 0 && it.totalTimeInForeground > 0 }
                .groupBy { it.packageName }
                .forEach { (pkgName, entries) ->
                    if (!installedPackages.containsKey(pkgName)) {
                        val lastUsed = entries.maxOf { it.lastTimeUsed }
                        rawEvidence += RawTraceEvidence(
                            key = pkgName,
                            appName = deriveAppLabelFromPackage(pkgName),
                            packageName = pkgName,
                            evidenceSource = "Android Usage History (UsageStatsManager)",
                            evidenceDetails = "Usage record found for package no longer present in PackageManager.",
                            location = "UsageStats/$pkgName",
                            lastModifiedMillis = lastUsed,
                            confidence = ConfidenceLevel.HIGH,
                            isPackageScoped = true
                        )
                    }
                }
        } else {
            unavailable += UnavailableCheck(
                checkName = "Historical Usage Statistics (UsageStatsManager)",
                category = "App Trace Scanner",
                reason = "PACKAGE_USAGE_STATS permission is not granted.",
                requiredAction = "Optional: Enable 'Usage access' for TK CHECKER in Settings to detect recently uninstalled app usage."
            )
        }

        // 5. Optional authorized root evidence (if already executed with explicit consent)
        val pkgListRootResult = rootCommandResults.firstOrNull {
            it.executed && it.command.contains("packages.list") && it.output.isNotBlank()
        }
        if (pkgListRootResult != null) {
            accessibleSources++
            // Parse package lines from /data/system/packages.list if any differ from non-root PackageManager
            pkgListRootResult.output.lines().forEach { line ->
                val pkg = line.trim().split(" ").firstOrNull()
                if (pkg != null && isValidPackageLikeName(pkg) && !installedPackages.containsKey(pkg)) {
                    rawEvidence += RawTraceEvidence(
                        key = pkg,
                        appName = deriveAppLabelFromPackage(pkg),
                        packageName = pkg,
                        evidenceSource = "Authorized Root System Registry (/data/system/packages.list)",
                        evidenceDetails = "Package record visible via read-only root inspection.",
                        location = "/data/system/packages.list",
                        lastModifiedMillis = null,
                        confidence = ConfidenceLevel.HIGH,
                        isPackageScoped = true
                    )
                }
            }
        }

        val aggregated = aggregateEvidence(rawEvidence, installedPackages, injectionFindings)
        val status = determineTraceStatus(aggregated, unavailable, accessibleSources)

        return TraceScanOutput(
            status = status,
            traces = aggregated,
            unavailableChecks = unavailable,
            accessibleSourcesCount = accessibleSources
        )
    }

    private fun readSafFolderTraces(
        ctx: Context,
        treeUri: Uri,
        installedPackages: Map<String, String?>
    ): List<RawTraceEvidence> {
        val list = mutableListOf<RawTraceEvidence>()
        runCatching {
            val docId = DocumentsContract.getTreeDocumentId(treeUri)
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            ctx.contentResolver.query(
                childrenUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
                ),
                null,
                null,
                null
            )?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val mimeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
                val modIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                while (cursor.moveToNext()) {
                    val name = cursor.getString(nameIdx) ?: continue
                    val mime = cursor.getString(mimeIdx) ?: ""
                    val modified = if (modIdx >= 0) cursor.getLong(modIdx) else 0L
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR && isValidPackageLikeName(name)) {
                        list += RawTraceEvidence(
                            key = name,
                            appName = installedPackages[name] ?: deriveAppLabelFromPackage(name),
                            packageName = name,
                            evidenceSource = "SAF Authorized Folder",
                            evidenceDetails = "Directory '$name' observed inside user-selected folder.",
                            location = "$treeUri/$name",
                            lastModifiedMillis = modified.takeIf { it > 0 },
                            confidence = ConfidenceLevel.HIGH,
                            isPackageScoped = true
                        )
                    }
                }
            }
        }
        return list
    }
}
