package com.tk.checker.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tk.checker.domain.model.AppSettings
import com.tk.checker.ui.components.TkKeyValueRow
import com.tk.checker.ui.components.TkSectionCard
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.TkUiState

@Composable
fun SettingsScreen(
    uiState: TkUiState,
    onUpdateSettings: ((AppSettings) -> AppSettings) -> Unit,
    onClearAllHistory: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TkColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TkSectionCard(borderColor = TkColors.CleanGreen.copy(alpha = 0.4f)) {
                Text("PRIVACY & ZERO-TELEMETRY GUARANTEE", style = MaterialTheme.typography.labelMedium, color = TkColors.CleanGreen)
                Spacer(Modifier.height(8.dp))
                Text(
                    "• Zero user accounts, zero ads, zero analytics, and zero third-party tracking SDKs.\n" +
                        "• All scan history and exported reports remain strictly local on your device.\n" +
                        "• Network permission is used solely for user-initiated TCP latency probes in Gaming Diagnostics.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        item {
            TkSectionCard {
                Text("PERMISSIONS & DIAGNOSTIC CONTROLS", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Read-Only Root Consent", style = MaterialTheme.typography.titleMedium)
                        Text("Allow whitelisted read-only 'su -c' diagnostics.", style = MaterialTheme.typography.bodyMedium)
                    }
                    Switch(
                        checked = uiState.settings.rootDiagnosticsConsentGranted,
                        onCheckedChange = { checked ->
                            onUpdateSettings { it.copy(rootDiagnosticsConsentGranted = checked) }
                        }
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Include Root Checks in Full Scan", style = MaterialTheme.typography.titleMedium)
                        Text("Runs read-only root checks automatically during SCAN NOW.", style = MaterialTheme.typography.bodyMedium)
                    }
                    Switch(
                        checked = uiState.settings.includeRootInFullScan,
                        onCheckedChange = { checked ->
                            onUpdateSettings { it.copy(includeRootInFullScan = checked) }
                        }
                    )
                }
                Spacer(Modifier.height(12.dp))
                TkKeyValueRow("Usage Access", if (uiState.usageStatsGranted) "GRANTED" else "NOT GRANTED")
                Spacer(Modifier.height(6.dp))
                OutlinedButton(
                    onClick = { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Manage Usage Access in Android Settings", color = TkColors.NeonBlue)
                }
            }
        }

        item {
            TkSectionCard(borderColor = TkColors.DetectedRed.copy(alpha = 0.4f)) {
                Text("LOCAL DATA CONTROL", style = MaterialTheme.typography.labelMedium, color = TkColors.DetectedRed)
                Spacer(Modifier.height(8.dp))
                Text("Delete all locally stored scan history, SAF folder tokens, and root preferences.", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        onClearAllHistory()
                        onUpdateSettings { AppSettings() }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TkColors.DetectedRed, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("DELETE ALL LOCAL DATA")
                }
            }
        }
    }
}
