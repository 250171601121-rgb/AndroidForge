package com.tk.checker.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object TkColors {
    val Background = Color(0xFF05060A)
    val Surface = Color(0xFF0D111A)
    val SurfaceElevated = Color(0xFF131926)
    val Border = Color(0xFF1E293B)
    val NeonBlue = Color(0xFF00E5FF)
    val NeonPurple = Color(0xFF9D4EDD)
    val CleanGreen = Color(0xFF10B981)
    val WarningAmber = Color(0xFFF59E0B)
    val DetectedRed = Color(0xFFEF4444)
    val UnavailableSlate = Color(0xFF64748B)
    val TextPrimary = Color(0xFFF1F5F9)
    val TextSecondary = Color(0xFF94A3B8)
}

private val DarkGamingColorScheme = darkColorScheme(
    primary = TkColors.NeonBlue,
    onPrimary = TkColors.Background,
    secondary = TkColors.NeonPurple,
    onSecondary = Color.White,
    background = TkColors.Background,
    onBackground = TkColors.TextPrimary,
    surface = TkColors.Surface,
    onSurface = TkColors.TextPrimary,
    surfaceVariant = TkColors.SurfaceElevated,
    onSurfaceVariant = TkColors.TextSecondary,
    outline = TkColors.Border,
    error = TkColors.DetectedRed,
    onError = Color.White
)

private val TkTypography = Typography(
    headlineLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        letterSpacing = (-0.5).sp,
        color = TkColors.TextPrimary
    ),
    titleLarge = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 19.sp,
        color = TkColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        color = TkColors.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        color = TkColors.TextSecondary
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        letterSpacing = 0.6.sp
    )
)

@Composable
fun TkCheckerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkGamingColorScheme,
        typography = TkTypography,
        content = content
    )
}
