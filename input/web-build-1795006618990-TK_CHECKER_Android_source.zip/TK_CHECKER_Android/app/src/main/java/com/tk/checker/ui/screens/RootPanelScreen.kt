package com.tk.checker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tk.checker.data.scanner.RootDiagnosticsEngine
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.ui.components.StatusPill
import com.tk.checker.ui.components.TkKeyValueRow
import com.tk.checker.ui.components.TkSectionCard
import com.tk.checker.ui.components.statusColor
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.TkUiState

@Composable
fun RootPanelScreen(
    uiState: TkUiState,
    commandSpecs: List<RootDiagnosticsEngine.ReadOnlyCommandSpec>,
    onGrantConsentAndRun: (Boolean) -> Unit,
    onRunRootDiagnostics: () -> Unit
) {
    var showConsentDialog by remember { mutableStateOf(false) }
    val root = uiState.currentReport?.rootAssessment
    val consentGranted = uiState.settings.rootDiagnosticsConsentGranted

    if (showConsentDialog) {
        AlertDialog(
            onDismissRequest = { showConsentDialog = false },
            containerColor = TkColors.SurfaceElevated,
            title = { Text("Authorize Read-Only Root Diagnostics", color = TkColors.TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "TK CHECKER will ONLY execute strictly whitelisted read-only commands via 'su -c':",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    commandSpecs.forEach { spec ->
                        Text(
                            "• ${spec.command} — ${spec.explanation}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            ),
                            color = TkColors.NeonBlue
                        )
                    }
                    Text(
                        "Zero files will be modified and Android security policies will never be altered.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TkColors.CleanGreen
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConsentDialog = false
                        onGrantConsentAndRun(true)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TkColors.NeonBlue, contentColor = Color.Black)
                ) {
                    Text("Authorize Read-Only")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConsentDialog = false }) {
                    Text("Cancel", color = TkColors.TextSecondary)
                }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TkColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TkSectionCard(borderColor = TkColors.NeonPurple.copy(alpha = 0.4f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ROOT VERIFICATION STATUS", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonPurple)
                    StatusPill(status = root?.status ?: ScanStatus.UNKNOWN)
                }
                Spacer(Modifier.height(10.dp))
                TkKeyValueRow("Root Availability", if (root?.rootCommandAvailable == true) "SU Binary Found" else "Not Detected")
                TkKeyValueRow("Rooted Verdict", if (root?.isRooted == true) "CONFIRMED" else "NOT CONFIRMED", valueColor = statusColor(root?.status ?: ScanStatus.UNKNOWN))
                TkKeyValueRow("Strong Signals", "${root?.strongMatches ?: 0}")
                TkKeyValueRow("Weak Signals", "${root?.weakMatches ?: 0}")
                TkKeyValueRow("Read-Only Consent", if (consentGranted) "GRANTED" else "NOT GRANTED", valueColor = if (consentGranted) TkColors.CleanGreen else TkColors.WarningAmber)
                Spacer(Modifier.height(8.dp))
                Text(
                    text = root?.explanation ?: "Run SCAN NOW on the dashboard to inspect observable root indicators.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        if (!consentGranted) showConsentDialog = true else onRunRootDiagnostics()
                    },
                    enabled = !uiState.isRunningRootDiagnostics,
                    colors = ButtonDefaults.buttonColors(containerColor = TkColors.NeonPurple, contentColor = Color.White),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        if (uiState.isRunningRootDiagnostics) "RUNNING..."
                        else if (consentGranted) "RUN READ-ONLY DIAGNOSTICS"
                        else "AUTHORIZE & RUN ROOT CHECKS"
                    )
                }
                if (consentGranted) {
                    OutlinedButton(onClick = { onGrantConsentAndRun(false) }) {
                        Text("Revoke", color = TkColors.WarningAmber)
                    }
                }
            }
        }

        if (root != null) {
            item {
                Text("OBSERVABLE ROOT SIGNALS", style = MaterialTheme.typography.labelMedium, color = TkColors.TextSecondary)
            }
            items(root.signals) { signal ->
                TkSectionCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(signal.name, style = MaterialTheme.typography.titleMedium)
                        val sigStatus = when {
                            !signal.accessible -> ScanStatus.UNAVAILABLE
                            signal.matched -> ScanStatus.DETECTED
                            else -> ScanStatus.CLEAN
                        }
                        StatusPill(status = sigStatus)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Strength: ${signal.strength.name} · Source: ${signal.evidenceSource}",
                        style = MaterialTheme.typography.labelMedium,
                        color = TkColors.NeonBlue
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(signal.details, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item {
            Text("READ-ONLY ROOT DIAGNOSTIC OUTPUT", style = MaterialTheme.typography.labelMedium, color = TkColors.TextSecondary)
        }

        if (uiState.rootCommandResults.isEmpty()) {
            item {
                TkSectionCard {
                    Text(
                        "No read-only root diagnostics executed yet. Explicit permission is required before invoking su.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        } else {
            items(uiState.rootCommandResults) { cmd ->
                TkSectionCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cmd.commandLabel, style = MaterialTheme.typography.titleMedium)
                        StatusPill(status = cmd.status)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "$ su -c \"${cmd.command}\"",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = TkColors.NeonBlue
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(cmd.description, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = cmd.error ?: cmd.output,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Normal,
                        color = if (cmd.error != null) TkColors.WarningAmber else TkColors.TextPrimary
                    )
                }
            }
        }
    }
}
