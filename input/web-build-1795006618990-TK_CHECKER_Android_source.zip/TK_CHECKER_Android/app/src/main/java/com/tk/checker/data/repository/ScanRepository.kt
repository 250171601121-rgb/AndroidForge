package com.tk.checker.data.repository

import android.content.Context
import com.tk.checker.domain.model.AppSettings
import com.tk.checker.domain.model.ScanComparison
import com.tk.checker.domain.model.ScanReport
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Local-only encrypted/private storage repository for Scan History and Settings.
 * Never uploads scan data or requires user accounts.
 */
class ScanRepository(private val context: Context) {

    private val json = Json {
        prettyPrint = false
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    private val historyFile: File
        get() = File(context.filesDir, "tk_scan_history.json")

    private val settingsFile: File
        get() = File(context.filesDir, "tk_settings.json")

    fun loadHistory(): List<ScanReport> {
        return runCatching {
            if (!historyFile.exists()) return emptyList()
            val raw = historyFile.readText()
            if (raw.isBlank()) return emptyList()
            json.decodeFromString<List<ScanReport>>(raw)
                .sortedByDescending { it.timestampMillis }
        }.getOrDefault(emptyList())
    }

    fun saveScan(report: ScanReport): List<ScanReport> {
        val current = loadHistory().filterNot { it.id == report.id }.toMutableList()
        current.add(0, report)
        val trimmed = current.take(50)
        runCatching {
            historyFile.writeText(json.encodeToString(trimmed))
        }
        return trimmed
    }

    fun deleteScan(scanId: String): List<ScanReport> {
        val updated = loadHistory().filterNot { it.id == scanId }
        runCatching {
            historyFile.writeText(json.encodeToString(updated))
        }
        return updated
    }

    fun clearAllHistory(): List<ScanReport> {
        runCatching {
            if (historyFile.exists()) historyFile.delete()
        }
        return emptyList()
    }

    fun loadSettings(): AppSettings {
        return runCatching {
            if (!settingsFile.exists()) return AppSettings()
            json.decodeFromString<AppSettings>(settingsFile.readText())
        }.getOrDefault(AppSettings())
    }

    fun saveSettings(settings: AppSettings) {
        runCatching {
            settingsFile.writeText(json.encodeToString(settings))
        }
    }

    companion object {
        fun compareScans(baseline: ScanReport, target: ScanReport): ScanComparison {
            val baseInjKeys = baseline.injectionFindings.map { it.id }.toSet()
            val targetInjKeys = target.injectionFindings.map { it.id }.toSet()

            val newInjections = target.injectionFindings.filter { it.id !in baseInjKeys }
            val resolvedInjections = baseline.injectionFindings.filter { it.id !in targetInjKeys }

            val baseTraceKeys = baseline.appTraces.map { it.packageName ?: it.id }.toSet()
            val targetTraceKeys = target.appTraces.map { it.packageName ?: it.id }.toSet()

            val newTraces = target.appTraces.filter { (it.packageName ?: it.id) !in baseTraceKeys }
            val resolvedTraces = baseline.appTraces.filter { (it.packageName ?: it.id) !in targetTraceKeys }

            val pingDelta = if (baseline.gamingDiagnostics.network.pingMs != null &&
                target.gamingDiagnostics.network.pingMs != null
            ) {
                target.gamingDiagnostics.network.pingMs - baseline.gamingDiagnostics.network.pingMs
            } else null

            return ScanComparison(
                baselineScanId = baseline.id,
                targetScanId = target.id,
                baselineTimestampMillis = baseline.timestampMillis,
                targetTimestampMillis = target.timestampMillis,
                rootStatusChanged = baseline.rootAssessment.status != target.rootAssessment.status,
                injectionDelta = target.injectionFindings.size - baseline.injectionFindings.size,
                traceDelta = target.appTraces.size - baseline.appTraces.size,
                newInjections = newInjections,
                resolvedInjections = resolvedInjections,
                newTraces = newTraces,
                resolvedTraces = resolvedTraces,
                pingDeltaMs = pingDelta,
                availableRamDeltaMb = target.gamingDiagnostics.availableRamMb - baseline.gamingDiagnostics.availableRamMb
            )
        }
    }
}
