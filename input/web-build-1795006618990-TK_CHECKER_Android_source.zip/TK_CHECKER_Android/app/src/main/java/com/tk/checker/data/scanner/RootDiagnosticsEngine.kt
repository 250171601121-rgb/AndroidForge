package com.tk.checker.data.scanner

import com.tk.checker.domain.model.RootCommandResult
import com.tk.checker.domain.model.ScanStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Strictly read-only root diagnostic runner.
 * Never modifies system files, never disables Android security,
 * and requires explicit user consent before invoking su.
 */
class RootDiagnosticsEngine {

    data class ReadOnlyCommandSpec(
        val id: String,
        val label: String,
        val command: String,
        val explanation: String
    )

    val whitelistedReadOnlyCommands = listOf(
        ReadOnlyCommandSpec(
            id = "uid_verify",
            label = "Verify Root Context",
            command = "id",
            explanation = "Read-only check verifying whether su grants uid=0(root) permission."
        ),
        ReadOnlyCommandSpec(
            id = "selinux_getenforce",
            label = "SELinux Mode",
            command = "getenforce",
            explanation = "Reads current SELinux enforcement state without modifying policy."
        ),
        ReadOnlyCommandSpec(
            id = "adb_modules",
            label = "Root Modules Inspection",
            command = "ls -la /data/adb/modules 2>/dev/null || echo 'NO_MODULES_DIR'",
            explanation = "Lists installed Magisk/KernelSU module folders (read-only) to identify system hooks."
        ),
        ReadOnlyCommandSpec(
            id = "local_tmp",
            label = "Temp Injection Artifacts",
            command = "ls -la /data/local/tmp 2>/dev/null",
            explanation = "Lists temporary binaries/scripts in /data/local/tmp (read-only) such as Frida servers."
        ),
        ReadOnlyCommandSpec(
            id = "root_mounts",
            label = "Overlay & Zygisk Mounts",
            command = "grep -iE 'magisk|ksu|apatch|zygisk|overlay' /proc/mounts 2>/dev/null || echo 'NO_MATCH'",
            explanation = "Inspects kernel mount table entries for active root/hooking overlays."
        ),
        ReadOnlyCommandSpec(
            id = "packages_list_traces",
            label = "System Package Records",
            command = "head -n 250 /data/system/packages.list 2>/dev/null",
            explanation = "Reads installed package UID registry (read-only) to cross-check orphaned /data/data traces."
        )
    )

    suspend fun executeReadOnlyDiagnostics(
        consentGranted: Boolean,
        rootAvailable: Boolean
    ): List<RootCommandResult> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (!consentGranted) {
            return@withContext whitelistedReadOnlyCommands.map { spec ->
                RootCommandResult(
                    commandLabel = spec.label,
                    command = spec.command,
                    description = spec.explanation,
                    executed = false,
                    status = ScanStatus.UNAVAILABLE,
                    output = "Skipped: Explicit user permission for read-only root commands has not been granted.",
                    timestampMillis = now
                )
            }
        }

        if (!rootAvailable) {
            return@withContext whitelistedReadOnlyCommands.map { spec ->
                RootCommandResult(
                    commandLabel = spec.label,
                    command = spec.command,
                    description = spec.explanation,
                    executed = false,
                    status = ScanStatus.UNAVAILABLE,
                    output = "Root binary (su) not detected on device.",
                    timestampMillis = now
                )
            }
        }

        whitelistedReadOnlyCommands.map { spec ->
            runSingleReadOnlyCommand(spec)
        }
    }

    private fun runSingleReadOnlyCommand(spec: ReadOnlyCommandSpec): RootCommandResult {
        val now = System.currentTimeMillis()
        return runCatching {
            val process = ProcessBuilder("su", "-c", spec.command)
                .redirectErrorStream(false)
                .start()

            val finished = process.waitFor(4, TimeUnit.SECONDS)
            if (!finished) {
                process.destroyForcibly()
                return RootCommandResult(
                    commandLabel = spec.label,
                    command = spec.command,
                    description = spec.explanation,
                    executed = false,
                    status = ScanStatus.UNAVAILABLE,
                    output = "",
                    error = "Timed out waiting for su permission prompt or command completion.",
                    timestampMillis = now
                )
            }

            val stdout = process.inputStream.bufferedReader().readText().trim()
            val stderr = process.errorStream.bufferedReader().readText().trim()
            val exitCode = process.exitValue()

            if (exitCode != 0 && stdout.isEmpty()) {
                RootCommandResult(
                    commandLabel = spec.label,
                    command = spec.command,
                    description = spec.explanation,
                    executed = false,
                    status = ScanStatus.UNAVAILABLE,
                    output = "",
                    error = stderr.ifEmpty { "Root access denied or command returned exit code $exitCode" },
                    timestampMillis = now
                )
            } else {
                val cappedOutput = stdout.lines().take(60).joinToString("\n")
                RootCommandResult(
                    commandLabel = spec.label,
                    command = spec.command,
                    description = spec.explanation,
                    executed = true,
                    status = ScanStatus.CLEAN,
                    output = cappedOutput.ifEmpty { "(empty output)" },
                    error = stderr.takeIf { it.isNotEmpty() },
                    timestampMillis = now
                )
            }
        }.getOrElse { ex ->
            RootCommandResult(
                commandLabel = spec.label,
                command = spec.command,
                description = spec.explanation,
                executed = false,
                status = ScanStatus.UNAVAILABLE,
                output = "",
                error = ex.message ?: "Unable to invoke su",
                timestampMillis = now
            )
        }
    }
}
