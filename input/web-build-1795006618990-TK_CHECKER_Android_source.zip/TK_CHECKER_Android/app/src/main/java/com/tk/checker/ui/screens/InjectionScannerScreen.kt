package com.tk.checker.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.ui.components.StatusPill
import com.tk.checker.ui.components.TkKeyValueRow
import com.tk.checker.ui.components.TkSectionCard
import com.tk.checker.ui.components.formatMillis
import com.tk.checker.ui.components.severityColor
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.TkUiState

@Composable
fun InjectionScannerScreen(uiState: TkUiState) {
    var filterConfirmedOnly by remember { mutableStateOf(false) }
    val report = uiState.currentReport
    val findings = report?.injectionFindings.orEmpty().let { list ->
        if (filterConfirmedOnly) list.filter { it.isConfirmedInjection } else list
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TkColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TkSectionCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("UNIVERSAL INJECTION SCANNER", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                    StatusPill(status = report?.injectionStatus ?: ScanStatus.UNKNOWN)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Inspects all accessible packages, native .so libraries, hooking frameworks, overlays, accessibility services, APK signatures, and accessible storage scripts.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !filterConfirmedOnly,
                        onClick = { filterConfirmedOnly = false },
                        label = { Text("All (${report?.injectionFindings?.size ?: 0})") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = TkColors.NeonBlue.copy(alpha = 0.2f))
                    )
                    FilterChip(
                        selected = filterConfirmedOnly,
                        onClick = { filterConfirmedOnly = true },
                        label = { Text("Confirmed Only") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = TkColors.DetectedRed.copy(alpha = 0.2f))
                    )
                }
            }
        }

        if (report == null) {
            item {
                TkSectionCard {
                    Text("Run SCAN NOW on the Dashboard to inspect installed packages and storage.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else if (findings.isEmpty()) {
            item {
                TkSectionCard(borderColor = TkColors.CleanGreen.copy(alpha = 0.4f)) {
                    Text("No matching injection or tampering indicators found in accessible scope.", style = MaterialTheme.typography.titleMedium, color = TkColors.CleanGreen)
                    Spacer(Modifier.height(4.dp))
                    Text("Inspected ${report.accessiblePackageCount} packages. Note: cross-app runtime memory remains protected by Android SELinux.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            items(findings, key = { it.id }) { item ->
                val sevColor = severityColor(item.severity)
                TkSectionCard(borderColor = sevColor.copy(alpha = 0.45f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.detectionName, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        Surface(
                            color = sevColor.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, sevColor.copy(alpha = 0.5f))
                        ) {
                            Text(
                                item.severity.name,
                                color = sevColor,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = if (item.isConfirmedInjection) "CONFIRMED INJECTION TOOL / LIBRARY" else "SUSPICIOUS INDICATOR (NOT CONFIRMED INJECTION)",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (item.isConfirmedInjection) TkColors.DetectedRed else TkColors.WarningAmber
                    )
                    Spacer(Modifier.height(8.dp))
                    TkKeyValueRow("Application", item.appName ?: "Unidentifiable")
                    TkKeyValueRow("Package Name", item.packageName)
                    TkKeyValueRow("Evidence Source", item.evidenceSource)
                    TkKeyValueRow("Confidence", item.confidence.name)
                    TkKeyValueRow("Status", item.availabilityStatus.name)
                    TkKeyValueRow("Timestamp", formatMillis(item.timestampMillis))
                    Spacer(Modifier.height(6.dp))
                    Text(item.evidenceDetails, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
