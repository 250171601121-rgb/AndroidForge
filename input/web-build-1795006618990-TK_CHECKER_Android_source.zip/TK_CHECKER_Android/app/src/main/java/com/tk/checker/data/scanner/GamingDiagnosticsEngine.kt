package com.tk.checker.data.scanner

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.view.Display
import android.view.WindowManager
import com.tk.checker.domain.model.FpsMeasurement
import com.tk.checker.domain.model.GamingDiagnosticsSnapshot
import com.tk.checker.domain.model.NetworkDiagnostics
import com.tk.checker.domain.model.ScanStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Hardware, Thermal, Display, Honest FPS, and Network Latency Diagnostics Engine.
 * Never fabricates FPS values or hidden hardware data.
 */
class GamingDiagnosticsEngine(private val context: Context) {

    suspend fun collect(probeHost: String = "1.1.1.1"): GamingDiagnosticsSnapshot =
        withContext(Dispatchers.IO) {
            val cpuInfo = readCpuModel()
            val cpuCores = Runtime.getRuntime().availableProcessors()
            val cpuAbis = Build.SUPPORTED_ABIS.toList()
            val cpuMaxFreqMhz = readMaxCpuFreqMhz()

            val gpuPair = readOffscreenGpuInfo()

            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)
            val totalRamMb = memInfo.totalMem / (1024 * 1024)
            val availRamMb = memInfo.availMem / (1024 * 1024)

            val statFs = StatFs(Environment.getDataDirectory().path)
            val totalStorageGb = (statFs.blockCountLong * statFs.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)
            val availStorageGb = (statFs.availableBlocksLong * statFs.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)

            val displayMetrics = context.resources.displayMetrics
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            @Suppress("DEPRECATION")
            val display: Display? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                runCatching { context.display }.getOrNull() ?: wm?.defaultDisplay
            } else {
                wm?.defaultDisplay
            }

            val refreshRate = display?.refreshRate ?: 60f
            val supportedRates = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && display != null) {
                display.supportedModes.map { it.refreshRate }.distinct().sorted()
            } else {
                listOf(refreshRate)
            }

            val batteryStatus = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val batteryPct = if (level >= 0 && scale > 0) (level * 100) / scale else -1
            val tempTenths = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            val batteryTempC = if (tempTenths != null && tempTenths != Int.MIN_VALUE) tempTenths / 10f else null
            val statusFlag = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = statusFlag == BatteryManager.BATTERY_STATUS_CHARGING ||
                statusFlag == BatteryManager.BATTERY_STATUS_FULL

            val (thermalAvailable, thermalLabel) = readThermalState()

            // System-wide cross-app FPS requires privileged SurfaceFlinger access on Android.
            // We NEVER generate fake FPS numbers.
            val fps = FpsMeasurement(
                available = false,
                valueFps = null,
                scopeDescription = "FPS MONITORING UNAVAILABLE — Android restricts cross-app SurfaceFlinger frame telemetry for non-system apps.",
                status = ScanStatus.UNAVAILABLE
            )

            val network = measureNetwork(probeHost)

            val overallStatus = when {
                !network.connected -> ScanStatus.WARNING
                thermalLabel.contains("SEVERE", ignoreCase = true) ||
                    thermalLabel.contains("CRITICAL", ignoreCase = true) -> ScanStatus.WARNING
                else -> ScanStatus.CLEAN
            }

            GamingDiagnosticsSnapshot(
                cpuModel = cpuInfo,
                cpuCores = cpuCores,
                cpuAbis = cpuAbis,
                cpuMaxFreqMhz = cpuMaxFreqMhz,
                gpuRenderer = gpuPair.first,
                gpuVendor = gpuPair.second,
                glEsVersion = am?.deviceConfigurationInfo?.glEsVersion ?: "Unknown",
                totalRamMb = totalRamMb,
                availableRamMb = availRamMb,
                totalStorageGb = (totalStorageGb * 10.0).roundToInt() / 10.0,
                availableStorageGb = (availStorageGb * 10.0).roundToInt() / 10.0,
                screenWidthPx = displayMetrics.widthPixels,
                screenHeightPx = displayMetrics.heightPixels,
                refreshRateHz = refreshRate,
                supportedRefreshRates = supportedRates,
                androidVersion = Build.VERSION.RELEASE,
                sdkInt = Build.VERSION.SDK_INT,
                batteryLevelPercent = batteryPct,
                batteryTempCelsius = batteryTempC,
                isCharging = isCharging,
                thermalStatusLabel = thermalLabel,
                thermalAvailable = thermalAvailable,
                fpsMeasurement = fps,
                network = network,
                status = overallStatus
            )
        }

    private fun readCpuModel(): String {
        val socModel = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Build.SOC_MODEL.takeIf { it != Build.UNKNOWN }
        } else null
        if (!socModel.isNullOrBlank()) return socModel

        val fromProc = runCatching {
            File("/proc/cpuinfo").readLines().firstOrNull {
                it.startsWith("Hardware", ignoreCase = true) || it.startsWith("model name", ignoreCase = true)
            }?.substringAfter(":")?.trim()
        }.getOrNull()

        return fromProc?.takeIf { it.isNotBlank() } ?: Build.HARDWARE
    }

    private fun readMaxCpuFreqMhz(): Int? {
        return runCatching {
            val coreCount = Runtime.getRuntime().availableProcessors()
            val freqs = (0 until coreCount).mapNotNull { idx ->
                val f = File("/sys/devices/system/cpu/cpu$idx/cpufreq/cpuinfo_max_freq")
                if (f.canRead()) f.readText().trim().toLongOrNull() else null
            }
            freqs.maxOrNull()?.let { (it / 1000L).toInt() }
        }.getOrNull()
    }

    private fun readOffscreenGpuInfo(): Pair<String, String> {
        return runCatching {
            val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val version = IntArray(2)
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) {
                return "UNAVAILABLE" to "UNAVAILABLE"
            }
            val attribList = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_NONE
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val numConfigs = IntArray(1)
            EGL14.eglChooseConfig(display, attribList, 0, configs, 0, 1, numConfigs, 0)
            val config = configs[0] ?: return "UNAVAILABLE" to "UNAVAILABLE"

            val ctxAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
            val eglContext = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, ctxAttribs, 0)
            val surfAttribs = intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE)
            val surface = EGL14.eglCreatePbufferSurface(display, config, surfAttribs, 0)
            EGL14.eglMakeCurrent(display, surface, surface, eglContext)

            val renderer = GLES20.glGetString(GLES20.GL_RENDERER) ?: "UNAVAILABLE"
            val vendor = GLES20.glGetString(GLES20.GL_VENDOR) ?: "UNAVAILABLE"

            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(display, surface)
            EGL14.eglDestroyContext(display, eglContext)
            EGL14.eglTerminate(display)

            renderer to vendor
        }.getOrElse {
            "UNAVAILABLE" to "UNAVAILABLE"
        }
    }

    private fun readThermalState(): Pair<Boolean, String> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return false to "UNAVAILABLE (Requires Android 10+ Thermal API)"
        }
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            ?: return false to "UNAVAILABLE"
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> true to "NORMAL (No Throttling)"
            PowerManager.THERMAL_STATUS_LIGHT -> true to "LIGHT (Warm)"
            PowerManager.THERMAL_STATUS_MODERATE -> true to "MODERATE (Mild Throttling Risk)"
            PowerManager.THERMAL_STATUS_SEVERE -> true to "SEVERE (Thermal Throttling)"
            PowerManager.THERMAL_STATUS_CRITICAL -> true to "CRITICAL (High Heat)"
            PowerManager.THERMAL_STATUS_EMERGENCY -> true to "EMERGENCY"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> true to "SHUTDOWN"
            else -> false to "UNKNOWN"
        }
    }

    private fun measureNetwork(host: String): NetworkDiagnostics {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = cm?.activeNetwork
        val caps = cm?.getNetworkCapabilities(activeNetwork)

        if (activeNetwork == null || caps == null ||
            !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        ) {
            return NetworkDiagnostics(
                connected = false,
                transportType = "Offline",
                pingMs = null,
                jitterMs = null,
                packetLossPercent = null,
                stabilityLabel = "DISCONNECTED",
                status = ScanStatus.WARNING,
                details = "No active internet transport detected."
            )
        }

        val transport = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "Other"
        }

        // Measure 5 real TCP socket handshake RTT probes to port 443 on target host
        val samples = mutableListOf<Double>()
        var failures = 0
        val totalProbes = 5
        repeat(totalProbes) {
            val startNs = System.nanoTime()
            val ok = runCatching {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, 443), 1500)
                }
                true
            }.getOrDefault(false)
            if (ok) {
                samples += (System.nanoTime() - startNs) / 1_000_000.0
            } else {
                failures++
            }
        }

        if (samples.isEmpty()) {
            return NetworkDiagnostics(
                connected = true,
                transportType = transport,
                pingMs = null,
                jitterMs = null,
                packetLossPercent = 100.0,
                stabilityLabel = "PROBE BLOCKED / PACKET LOSS",
                status = ScanStatus.WARNING,
                details = "Connected via $transport, but TCP latency probes to $host:443 failed ($failures/$totalProbes)."
            )
        }

        val avgPing = (samples.average() * 10.0).roundToInt() / 10.0
        val mean = samples.average()
        val variance = samples.map { (it - mean) * (it - mean) }.average()
        val jitter = (sqrt(variance) * 10.0).roundToInt() / 10.0
        val lossPct = ((failures.toDouble() / totalProbes) * 100.0 * 10.0).roundToInt() / 10.0

        val stability = when {
            lossPct > 20.0 || avgPing > 180.0 -> "UNSTABLE"
            jitter > 25.0 || avgPing > 90.0 -> "MODERATE"
            else -> "STABLE"
        }

        return NetworkDiagnostics(
            connected = true,
            transportType = transport,
            pingMs = avgPing,
            jitterMs = jitter,
            packetLossPercent = lossPct,
            stabilityLabel = stability,
            status = if (stability == "UNSTABLE") ScanStatus.WARNING else ScanStatus.CLEAN,
            details = "Measured $totalProbes TCP probes to $host:443 over $transport (avg ${avgPing}ms, jitter ${jitter}ms, loss ${lossPct}%)."
        )
    }
}
