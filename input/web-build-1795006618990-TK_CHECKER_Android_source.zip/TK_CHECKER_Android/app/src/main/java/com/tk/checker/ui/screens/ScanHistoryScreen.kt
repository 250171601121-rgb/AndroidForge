package com.tk.checker.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tk.checker.domain.model.ScanReport
import com.tk.checker.ui.components.StatusPill
import com.tk.checker.ui.components.TkKeyValueRow
import com.tk.checker.ui.components.TkSectionCard
import com.tk.checker.ui.components.formatMillis
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.TkUiState

@Composable
fun ScanHistoryScreen(
    uiState: TkUiState,
    onSelectReport: (ScanReport) -> Unit,
    onCompareReports: (ScanReport, ScanReport) -> Unit,
    onClearComparison: () -> Unit,
    onDeleteScan: (String) -> Unit,
    onClearAll: () -> Unit,
    onExportReport: (ScanReport, Boolean) -> Uri?
) {
    val context = LocalContext.current
    var selectedCompareId by remember { mutableStateOf<String?>(null) }

    fun shareFile(uri: Uri?, mimeType: String) {
        if (uri == null) return
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Export TK CHECKER Report"))
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TkColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("LOCAL SCAN HISTORY (${uiState.history.size})", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonPurple)
                if (uiState.history.isNotEmpty()) {
                    OutlinedButton(onClick = onClearAll) {
                        Text("Clear All", color = TkColors.DetectedRed)
                    }
                }
            }
        }

        uiState.comparison?.let { comp ->
            item {
                TkSectionCard(borderColor = TkColors.NeonBlue.copy(alpha = 0.5f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SCAN COMPARISON DELTA", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                        OutlinedButton(onClick = onClearComparison) {
                            Text("Close")
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    TkKeyValueRow("Baseline", formatMillis(comp.baselineTimestampMillis))
                    TkKeyValueRow("Target", formatMillis(comp.targetTimestampMillis))
                    TkKeyValueRow("Root Changed", if (comp.rootStatusChanged) "YES" else "No")
                    TkKeyValueRow("Injection Delta", "${comp.injectionDelta}")
                    TkKeyValueRow("App Trace Delta", "${comp.traceDelta}")
                    TkKeyValueRow("RAM Delta", "${comp.availableRamDeltaMb} MB")
                    TkKeyValueRow("Ping Delta", comp.pingDeltaMs?.let { "$it ms" } ?: "N/A")
                }
            }
        }

        if (uiState.history.isEmpty()) {
            item {
                TkSectionCard {
                    Text("No saved scans yet. Run SCAN NOW on the Dashboard to store your first local report.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            items(uiState.history, key = { it.id }) { report ->
                val isSelectedCompare = selectedCompareId == report.id
                TkSectionCard(
                    borderColor = if (isSelectedCompare) TkColors.NeonBlue else TkColors.Border
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(formatMillis(report.timestampMillis), style = MaterialTheme.typography.titleMedium)
                        StatusPill(status = report.overallStatus)
                    }
                    Spacer(Modifier.height(6.dp))
                    TkKeyValueRow("Device", "${report.device.manufacturer} ${report.device.model}")
                    TkKeyValueRow("Root", report.rootAssessment.status.name)
                    TkKeyValueRow("Injections", "${report.injectionFindings.size} finding(s)")
                    TkKeyValueRow("Traces", "${report.appTraces.size} trace(s)")
                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onSelectReport(report) },
                            colors = ButtonDefaults.buttonColors(containerColor = TkColors.NeonBlue, contentColor = Color.Black),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Load")
                        }
                        OutlinedButton(
                            onClick = {
                                if (selectedCompareId == null) {
                                    selectedCompareId = report.id
                                } else if (selectedCompareId == report.id) {
                                    selectedCompareId = null
                                } else {
                                    val base = uiState.history.firstOrNull { it.id == selectedCompareId }
                                    if (base != null) onCompareReports(base, report)
                                    selectedCompareId = null
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (isSelectedCompare) "Pick 2nd" else if (selectedCompareId != null) "Compare" else "Compare")
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { shareFile(onExportReport(report, true), "application/pdf") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Export PDF", color = TkColors.NeonPurple)
                        }
                        OutlinedButton(
                            onClick = { shareFile(onExportReport(report, false), "text/plain") },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Export TXT", color = TkColors.NeonBlue)
                        }
                        Spacer(Modifier.width(4.dp))
                        OutlinedButton(onClick = { onDeleteScan(report.id) }) {
                            Text("Delete", color = TkColors.DetectedRed)
                        }
                    }
                }
            }
        }
    }
}
