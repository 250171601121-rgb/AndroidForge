package com.tk.checker.ui.screens

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.FolderDelete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.ui.components.ModuleTileCard
import com.tk.checker.ui.components.StatusPill
import com.tk.checker.ui.components.TkKeyValueRow
import com.tk.checker.ui.components.TkSectionCard
import com.tk.checker.ui.components.TkShieldLogo
import com.tk.checker.ui.components.formatMillis
import com.tk.checker.ui.components.statusColor
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.TkUiState

object Routes {
    const val DASHBOARD = "dashboard"
    const val ROOT_PANEL = "root_panel"
    const val NON_ROOT_PANEL = "non_root_panel"
    const val INJECTION_SCANNER = "injection_scanner"
    const val TRACE_SCANNER = "trace_scanner"
    const val GAMING_DIAGNOSTICS = "gaming_diagnostics"
    const val FREE_FIRE = "free_fire"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
}

@Composable
fun DashboardScreen(
    uiState: TkUiState,
    onRunScan: () -> Unit,
    onNavigate: (String) -> Unit
) {
    val report = uiState.currentReport
    val deviceModel = report?.device?.let { "${it.manufacturer} ${it.model}" }
        ?: "${Build.MANUFACTURER.replaceFirstChar { it.uppercaseChar() }} ${Build.MODEL}"
    val androidVer = report?.device?.let { "Android ${it.androidRelease} (API ${it.sdkInt})" }
        ?: "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

    val rootStatus = report?.rootAssessment?.status ?: ScanStatus.UNKNOWN
    val securityStatus = report?.securityStatus ?: ScanStatus.UNKNOWN
    val overallStatus = report?.overallStatus ?: ScanStatus.UNKNOWN

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TkColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Brand Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TkShieldLogo(size = 48.dp, animated = uiState.isScanning)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "TK CHECKER",
                            style = MaterialTheme.typography.headlineLarge,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Android Security & Gaming Diagnostics",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
                            color = TkColors.NeonBlue
                        )
                    }
                }
                StatusPill(status = overallStatus)
            }
        }

        // Device & Overall Scan Telemetry Card
        item {
            TkSectionCard(
                borderColor = statusColor(overallStatus).copy(alpha = 0.4f)
            ) {
                Text("DEVICE & SECURITY OVERVIEW", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                Spacer(Modifier.height(10.dp))
                TkKeyValueRow("Device Model", deviceModel)
                TkKeyValueRow("Android Version", androidVer)
                TkKeyValueRow("Root Status", rootStatus.name, valueColor = statusColor(rootStatus))
                TkKeyValueRow("Security Status", securityStatus.name, valueColor = statusColor(securityStatus))
                TkKeyValueRow("Overall Result", overallStatus.name, valueColor = statusColor(overallStatus))
                TkKeyValueRow(
                    "Last Scan",
                    report?.let { formatMillis(it.timestampMillis) } ?: "No scan executed yet"
                )
            }
        }

        // Large SCAN NOW Button + Progress
        item {
            val buttonBrush = Brush.horizontalGradient(
                colors = listOf(TkColors.NeonBlue, TkColors.NeonPurple)
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(buttonBrush)
            ) {
                Button(
                    onClick = onRunScan,
                    enabled = !uiState.isScanning,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                ) {
                    Text(
                        text = if (uiState.isScanning) "SCANNING DEVICE..." else "SCAN NOW",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.4.sp,
                        color = if (uiState.isScanning) Color.White else TkColors.Background
                    )
                }
            }

            AnimatedVisibility(visible = uiState.isScanning) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    LinearProgressIndicator(
                        progress = { uiState.scanProgress },
                        color = TkColors.NeonBlue,
                        trackColor = TkColors.SurfaceElevated,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = uiState.scanStageLabel,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = TkColors.NeonBlue
                    )
                }
            }
        }

        // Module Navigation Grid (2-column pairs)
        item {
            Text(
                text = "DIAGNOSTIC MODULES",
                style = MaterialTheme.typography.labelMedium,
                color = TkColors.TextSecondary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ModuleTileCard(
                    title = "ROOT PANEL",
                    subtitle = "Verify su, read-only root & system hooks",
                    icon = Icons.Rounded.AdminPanelSettings,
                    accent = TkColors.NeonPurple,
                    status = report?.rootAssessment?.status,
                    onClick = { onNavigate(Routes.ROOT_PANEL) },
                    modifier = Modifier.weight(1f)
                )
                ModuleTileCard(
                    title = "NON-ROOT PANEL",
                    subtitle = "Standard sandbox inspection & limits",
                    icon = Icons.Rounded.Security,
                    accent = TkColors.NeonBlue,
                    status = report?.securityStatus,
                    onClick = { onNavigate(Routes.NON_ROOT_PANEL) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ModuleTileCard(
                    title = "INJECTION SCANNER",
                    subtitle = report?.let { "${it.injectionFindings.size} finding(s) across ${it.accessiblePackageCount} pkgs" }
                        ?: "Libs, overlays, hooks & APK integrity",
                    icon = Icons.Rounded.BugReport,
                    accent = TkColors.DetectedRed,
                    status = report?.injectionStatus,
                    onClick = { onNavigate(Routes.INJECTION_SCANNER) },
                    modifier = Modifier.weight(1f)
                )
                ModuleTileCard(
                    title = "APP TRACE SCANNER",
                    subtitle = report?.let { "${it.appTraces.size} trace record(s) found" }
                        ?: "Universal deleted app evidence",
                    icon = Icons.Rounded.FolderDelete,
                    accent = TkColors.WarningAmber,
                    status = report?.traceStatus,
                    onClick = { onNavigate(Routes.TRACE_SCANNER) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ModuleTileCard(
                    title = "GAMING DIAGNOSTICS",
                    subtitle = "CPU, GPU, RAM, Hz, thermal & ping",
                    icon = Icons.Rounded.Memory,
                    accent = TkColors.NeonBlue,
                    status = report?.gamingDiagnostics?.status,
                    onClick = { onNavigate(Routes.GAMING_DIAGNOSTICS) },
                    modifier = Modifier.weight(1f)
                )
                ModuleTileCard(
                    title = "FREE FIRE COMPAT",
                    subtitle = report?.freeFireReport?.overallTier ?: "Hardware & network readiness",
                    icon = Icons.Rounded.SportsEsports,
                    accent = TkColors.CleanGreen,
                    status = report?.freeFireReport?.status,
                    onClick = { onNavigate(Routes.FREE_FIRE) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ModuleTileCard(
                    title = "SCAN HISTORY",
                    subtitle = "${uiState.history.size} saved report(s) · Compare & Export",
                    icon = Icons.Rounded.History,
                    accent = TkColors.NeonPurple,
                    status = null,
                    onClick = { onNavigate(Routes.HISTORY) },
                    modifier = Modifier.weight(1f)
                )
                ModuleTileCard(
                    title = "SETTINGS",
                    subtitle = "Permissions, root consent & privacy",
                    icon = Icons.Rounded.Settings,
                    accent = TkColors.TextSecondary,
                    status = null,
                    onClick = { onNavigate(Routes.SETTINGS) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
