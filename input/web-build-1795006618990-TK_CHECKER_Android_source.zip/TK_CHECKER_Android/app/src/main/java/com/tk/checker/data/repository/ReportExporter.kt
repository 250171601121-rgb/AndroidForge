package com.tk.checker.data.repository

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import com.tk.checker.domain.model.ScanReport
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Generates native PDF and structured TXT diagnostic reports locally
 * and exposes them securely via FileProvider.
 */
class ReportExporter(private val context: Context) {

    companion object {
        fun formatTimestamp(millis: Long): String {
            val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US)
            return fmt.format(Date(millis))
        }

        fun buildTxtReport(report: ScanReport): String {
            return buildString {
                appendLine("============================================================")
                appendLine("TK CHECKER — ANDROID SECURITY & DIAGNOSTIC REPORT")
                appendLine("============================================================")
                appendLine("Report ID      : ${report.id}")
                appendLine("Generated At   : ${formatTimestamp(report.timestampMillis)}")
                appendLine("Overall Status : ${report.overallStatus.name}")
                appendLine("Security Status: ${report.securityStatus.name}")
                appendLine()
                appendLine("[1] DEVICE INFORMATION")
                appendLine("Manufacturer   : ${report.device.manufacturer}")
                appendLine("Model          : ${report.device.model} (${report.device.brand})")
                appendLine("Android Version: ${report.device.androidRelease} (SDK ${report.device.sdkInt})")
                appendLine("Security Patch : ${report.device.securityPatch}")
                appendLine("Build Tags     : ${report.device.buildTags}")
                appendLine("ABIs           : ${report.device.abiList.joinToString(", ")}")
                appendLine()
                appendLine("[2] ROOT ASSESSMENT")
                appendLine("Status         : ${report.rootAssessment.status.name}")
                appendLine("Summary        : ${report.rootAssessment.summary}")
                appendLine("Explanation    : ${report.rootAssessment.explanation}")
                report.rootAssessment.signals.forEach { sig ->
                    appendLine(" - ${sig.name} [${sig.strength}] | accessible=${sig.accessible} | matched=${sig.matched}")
                    appendLine("   Source: ${sig.evidenceSource} | ${sig.details}")
                }
                appendLine()
                appendLine("[3] UNIVERSAL INJECTION & TAMPER SCAN (${report.injectionStatus.name})")
                appendLine("Inspected Pkgs : ${report.accessiblePackageCount}")
                if (report.injectionFindings.isEmpty()) {
                    appendLine("No suspicious injection or tampering indicators observed in accessible scope.")
                } else {
                    report.injectionFindings.forEachIndexed { idx, f ->
                        appendLine(" #${idx + 1} ${f.detectionName} [${f.severity} / ${f.confidence}]")
                        appendLine("   App        : ${f.appName ?: "Unknown"} (${f.packageName})")
                        appendLine("   Type       : ${if (f.isConfirmedInjection) "CONFIRMED INJECTION" else "SUSPICIOUS INDICATOR"}")
                        appendLine("   Status     : ${f.availabilityStatus.name}")
                        appendLine("   Source     : ${f.evidenceSource}")
                        appendLine("   Details    : ${f.evidenceDetails}")
                        appendLine("   Timestamp  : ${formatTimestamp(f.timestampMillis)}")
                    }
                }
                appendLine()
                appendLine("[4] UNIVERSAL DELETED / HISTORICAL APP TRACES (${report.traceStatus.name})")
                if (report.appTraces.isEmpty()) {
                    appendLine("No accessible leftover application traces detected.")
                } else {
                    report.appTraces.forEachIndexed { idx, t ->
                        appendLine(" #${idx + 1} App: ${t.appName ?: "Unidentifiable"} | Pkg: ${t.packageName ?: "Unknown"}")
                        appendLine("   Status     : ${t.status.name}")
                        appendLine("   Trace Count: ${t.verifiedTraceCount}")
                        appendLine("   Confidence : ${t.confidence.name}")
                        appendLine("   Injection  : ${t.injectionNote}")
                        appendLine("   Source     : ${t.evidenceSource}")
                        appendLine("   Details    : ${t.evidenceDetails}")
                        appendLine("   Locations  : ${t.locations.joinToString("; ")}")
                        appendLine("   Modified   : ${t.lastModifiedMillis?.let { formatTimestamp(it) } ?: "Unknown"}")
                    }
                }
                appendLine()
                appendLine("[5] GAMING DIAGNOSTICS & FREE FIRE COMPATIBILITY")
                val g = report.gamingDiagnostics
                appendLine("CPU            : ${g.cpuModel} (${g.cpuCores} cores, max ${g.cpuMaxFreqMhz ?: "?"} MHz)")
                appendLine("GPU            : ${g.gpuRenderer} (${g.gpuVendor}, GLES ${g.glEsVersion})")
                appendLine("RAM            : ${g.availableRamMb} MB free / ${g.totalRamMb} MB total")
                appendLine("Storage        : ${g.availableStorageGb} GB free / ${g.totalStorageGb} GB total")
                appendLine("Display        : ${g.screenWidthPx}x${g.screenHeightPx} @ ${g.refreshRateHz} Hz")
                appendLine("Battery/Thermal: ${g.batteryLevelPercent}% (${g.batteryTempCelsius ?: "?"} C) | ${g.thermalStatusLabel}")
                appendLine("FPS Status     : ${g.fpsMeasurement.scopeDescription}")
                appendLine("Network        : ${g.network.transportType} | Ping=${g.network.pingMs ?: "N/A"} ms | Jitter=${g.network.jitterMs ?: "N/A"} ms | Loss=${g.network.packetLossPercent ?: "N/A"}%")
                appendLine("Free Fire Tier : ${report.freeFireReport.overallTier} | Graphics: ${report.freeFireReport.recommendedGraphics} | FPS: ${report.freeFireReport.recommendedFpsSetting}")
                appendLine()
                appendLine("[6] UNAVAILABLE / ANDROID-RESTRICTED CHECKS")
                if (report.unavailableChecks.isEmpty()) {
                    appendLine("All queried checks were accessible.")
                } else {
                    report.unavailableChecks.forEach { u ->
                        appendLine(" - [${u.category}] ${u.checkName}: UNAVAILABLE — ${u.reason}")
                    }
                }
                appendLine("============================================================")
            }
        }
    }

    fun exportTxt(report: ScanReport): Uri {
        val dir = File(context.filesDir, "reports").apply { mkdirs() }
        val file = File(dir, "tk_checker_report_${report.id.take(8)}.txt")
        file.writeText(buildTxtReport(report))
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    fun exportPdf(report: ScanReport): Uri {
        val dir = File(context.filesDir, "reports").apply { mkdirs() }
        val file = File(dir, "tk_checker_report_${report.id.take(8)}.pdf")

        val pdf = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 36f
        val lineHeight = 14f

        val titlePaint = Paint().apply {
            color = Color.rgb(0, 212, 255)
            textSize = 18f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            isAntiAlias = true
        }
        val headerPaint = Paint().apply {
            color = Color.rgb(157, 78, 221)
            textSize = 11f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            isAntiAlias = true
        }
        val bodyPaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            isAntiAlias = true
        }
        val bgPaint = Paint().apply {
            color = Color.rgb(7, 9, 15)
        }

        val lines = buildTxtReport(report).lines()
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdf.startPage(pageInfo)
        page.canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        var y = margin + 12f
        page.canvas.drawText("TK CHECKER // DIAGNOSTIC REPORT", margin, y, titlePaint)
        y += 22f

        for (rawLine in lines) {
            val wrapped = wrapLine(rawLine, 82)
            for (line in wrapped) {
                if (y > pageHeight - margin) {
                    pdf.finishPage(page)
                    pageNumber++
                    pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    page = pdf.startPage(pageInfo)
                    page.canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)
                    y = margin
                }
                val paint = if (line.startsWith("[") && line.endsWith("]")) headerPaint else bodyPaint
                page.canvas.drawText(line, margin, y, paint)
                y += lineHeight
            }
        }
        pdf.finishPage(page)

        FileOutputStream(file).use { out ->
            pdf.writeTo(out)
        }
        pdf.close()

        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    private fun wrapLine(text: String, maxChars: Int): List<String> {
        if (text.length <= maxChars) return listOf(text)
        val result = mutableListOf<String>()
        var idx = 0
        while (idx < text.length) {
            val end = minOf(idx + maxChars, text.length)
            result += text.substring(idx, end)
            idx = end
        }
        return result
    }
}
