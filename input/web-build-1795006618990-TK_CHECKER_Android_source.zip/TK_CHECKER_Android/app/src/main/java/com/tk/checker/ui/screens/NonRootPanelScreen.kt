package com.tk.checker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.ui.components.StatusPill
import com.tk.checker.ui.components.TkKeyValueRow
import com.tk.checker.ui.components.TkSectionCard
import com.tk.checker.ui.components.statusColor
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.TkUiState

@Composable
fun NonRootPanelScreen(uiState: TkUiState) {
    val report = uiState.currentReport

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TkColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (report == null) {
            item {
                TkSectionCard {
                    Text("No Scan Data Available", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text("Tap SCAN NOW on the Dashboard to run non-root sandbox diagnostics.", style = MaterialTheme.typography.bodyMedium)
                }
            }
            return@LazyColumn
        }

        item {
            TkSectionCard(borderColor = TkColors.NeonBlue.copy(alpha = 0.35f)) {
                Text("DEVICE & SANDBOX PROFILE", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                Spacer(Modifier.height(8.dp))
                TkKeyValueRow("Model", "${report.device.manufacturer} ${report.device.model}")
                TkKeyValueRow("Android OS", "${report.device.androidRelease} (SDK ${report.device.sdkInt})")
                TkKeyValueRow("Security Patch", report.device.securityPatch)
                TkKeyValueRow("Build Tags", report.device.buildTags)
                TkKeyValueRow("Root Indicators", report.rootAssessment.status.name, valueColor = statusColor(report.rootAssessment.status))
                TkKeyValueRow("Accessible Apps", "${report.accessiblePackageCount} packages inspected")
                TkKeyValueRow("Injection Indicators", "${report.injectionFindings.size} (${report.injectionStatus.name})", valueColor = statusColor(report.injectionStatus))
                TkKeyValueRow("Historical Traces", "${report.appTraces.size} (${report.traceStatus.name})", valueColor = statusColor(report.traceStatus))
                TkKeyValueRow("Free Fire Tier", report.freeFireReport.overallTier)
            }
        }

        item {
            val g = report.gamingDiagnostics
            TkSectionCard {
                Text("HARDWARE, THERMAL & NETWORK (NON-ROOT)", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                Spacer(Modifier.height(8.dp))
                TkKeyValueRow("CPU", "${g.cpuModel} (${g.cpuCores} cores)")
                TkKeyValueRow("GPU", g.gpuRenderer)
                TkKeyValueRow("RAM", "${g.availableRamMb} MB free / ${g.totalRamMb} MB total")
                TkKeyValueRow("Storage", "${g.availableStorageGb} GB free / ${g.totalStorageGb} GB")
                TkKeyValueRow("Display Refresh", "${g.refreshRateHz.toInt()} Hz (${g.screenWidthPx}x${g.screenHeightPx})")
                TkKeyValueRow("Thermal", g.thermalStatusLabel)
                TkKeyValueRow("Network", "${g.network.transportType} · ${g.network.pingMs ?: "N/A"} ms (${g.network.stabilityLabel})")
            }
        }

        item {
            Text(
                "CHECKS BLOCKED BY ANDROID SANDBOX (UNAVAILABLE)",
                style = MaterialTheme.typography.labelMedium,
                color = TkColors.WarningAmber
            )
        }

        items(report.unavailableChecks) { blocked ->
            TkSectionCard(borderColor = TkColors.UnavailableSlate.copy(alpha = 0.45f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(blocked.checkName, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    StatusPill(status = ScanStatus.UNAVAILABLE)
                }
                Spacer(Modifier.height(4.dp))
                Text(blocked.category, style = MaterialTheme.typography.labelMedium, color = TkColors.NeonPurple)
                Spacer(Modifier.height(4.dp))
                Text(blocked.reason, style = MaterialTheme.typography.bodyMedium)
                if (!blocked.requiredAction.isNullOrBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(blocked.requiredAction, style = MaterialTheme.typography.bodyMedium, color = TkColors.NeonBlue)
                }
            }
        }
    }
}
