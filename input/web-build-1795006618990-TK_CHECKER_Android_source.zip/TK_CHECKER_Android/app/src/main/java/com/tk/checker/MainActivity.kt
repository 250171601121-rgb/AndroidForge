package com.tk.checker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.FolderDelete
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tk.checker.ui.screens.DashboardScreen
import com.tk.checker.ui.screens.FreeFireScreen
import com.tk.checker.ui.screens.GamingDiagnosticsScreen
import com.tk.checker.ui.screens.InjectionScannerScreen
import com.tk.checker.ui.screens.NonRootPanelScreen
import com.tk.checker.ui.screens.RootPanelScreen
import com.tk.checker.ui.screens.Routes
import com.tk.checker.ui.screens.ScanHistoryScreen
import com.tk.checker.ui.screens.SettingsScreen
import com.tk.checker.ui.screens.TraceScannerScreen
import com.tk.checker.ui.theme.TkCheckerTheme
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TkCheckerTheme {
                TkCheckerApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TkCheckerApp(viewModel: MainViewModel = viewModel()) {
    val navController = rememberNavController()
    val uiState by viewModel.uiState.collectAsState()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: Routes.DASHBOARD
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.exportMessage, uiState.errorMessage) {
        val msg = uiState.errorMessage ?: uiState.exportMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessages()
        }
    }

    val screenTitle = when (currentRoute) {
        Routes.DASHBOARD -> "TK CHECKER"
        Routes.ROOT_PANEL -> "Root Panel"
        Routes.NON_ROOT_PANEL -> "Non-Root Panel"
        Routes.INJECTION_SCANNER -> "Injection Scanner"
        Routes.TRACE_SCANNER -> "App Trace Scanner"
        Routes.GAMING_DIAGNOSTICS -> "Gaming Diagnostics"
        Routes.FREE_FIRE -> "Free Fire Compatibility"
        Routes.HISTORY -> "Scan History"
        Routes.SETTINGS -> "Settings"
        else -> "TK CHECKER"
    }

    Scaffold(
        containerColor = TkColors.Background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (currentRoute != Routes.DASHBOARD) {
                TopAppBar(
                    title = { Text(screenTitle, fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(
                                Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = TkColors.NeonBlue
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = TkColors.Surface,
                        titleContentColor = TkColors.TextPrimary
                    )
                )
            }
        },
        bottomBar = {
            NavigationBar(containerColor = TkColors.Surface) {
                val items = listOf(
                    Triple(Routes.DASHBOARD, "Home", Icons.Rounded.Dashboard),
                    Triple(Routes.INJECTION_SCANNER, "Inject", Icons.Rounded.BugReport),
                    Triple(Routes.TRACE_SCANNER, "Traces", Icons.Rounded.FolderDelete),
                    Triple(Routes.GAMING_DIAGNOSTICS, "Gaming", Icons.Rounded.SportsEsports),
                    Triple(Routes.HISTORY, "History", Icons.Rounded.History)
                )
                items.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = currentRoute == route,
                        onClick = {
                            navController.navigate(route) {
                                popUpTo(Routes.DASHBOARD) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = TkColors.NeonBlue,
                            selectedTextColor = TkColors.NeonBlue,
                            indicatorColor = TkColors.NeonBlue.copy(alpha = 0.14f),
                            unselectedIconColor = TkColors.TextSecondary,
                            unselectedTextColor = TkColors.TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.DASHBOARD,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(
                    uiState = uiState,
                    onRunScan = { viewModel.runFullScan() },
                    onNavigate = { route -> navController.navigate(route) }
                )
            }
            composable(Routes.ROOT_PANEL) {
                RootPanelScreen(
                    uiState = uiState,
                    commandSpecs = viewModel.rootCommandSpecs,
                    onGrantConsentAndRun = { grant -> viewModel.grantRootConsentAndRun(grant) },
                    onRunRootDiagnostics = { viewModel.runReadOnlyRootDiagnostics() }
                )
            }
            composable(Routes.NON_ROOT_PANEL) {
                NonRootPanelScreen(uiState = uiState)
            }
            composable(Routes.INJECTION_SCANNER) {
                InjectionScannerScreen(uiState = uiState)
            }
            composable(Routes.TRACE_SCANNER) {
                TraceScannerScreen(
                    uiState = uiState,
                    onSaveSafUri = { uri -> viewModel.saveSafTreeUri(uri) },
                    onRescan = { viewModel.runFullScan() }
                )
            }
            composable(Routes.GAMING_DIAGNOSTICS) {
                GamingDiagnosticsScreen(
                    uiState = uiState,
                    onRunScan = { viewModel.runFullScan() }
                )
            }
            composable(Routes.FREE_FIRE) {
                FreeFireScreen(uiState = uiState)
            }
            composable(Routes.HISTORY) {
                ScanHistoryScreen(
                    uiState = uiState,
                    onSelectReport = {
                        viewModel.selectReport(it)
                        navController.navigate(Routes.DASHBOARD)
                    },
                    onCompareReports = { a, b -> viewModel.compareReports(a, b) },
                    onClearComparison = { viewModel.clearComparison() },
                    onDeleteScan = { id -> viewModel.deleteScan(id) },
                    onClearAll = { viewModel.clearAllHistory() },
                    onExportReport = { rep, pdf -> viewModel.exportReportUri(rep, pdf) }
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    uiState = uiState,
                    onUpdateSettings = { fn -> viewModel.updateSettings(fn) },
                    onClearAllHistory = { viewModel.clearAllHistory() }
                )
            }
        }
    }
}
