package com.tk.checker.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class ScanStatus {
    CLEAN,
    WARNING,
    DETECTED,
    UNAVAILABLE,
    UNKNOWN
}

@Serializable
enum class FindingSeverity {
    INFO,
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

@Serializable
enum class ConfidenceLevel {
    LOW,
    MEDIUM,
    HIGH
}

@Serializable
enum class EvidenceAvailability {
    INSTALLED,
    UNINSTALLED,
    UNAVAILABLE,
    STORED_ARTIFACT
}

@Serializable
enum class SignalStrength {
    STRONG,
    MODERATE,
    WEAK
}

@Serializable
data class RootSignal(
    val id: String,
    val name: String,
    val strength: SignalStrength,
    val matched: Boolean,
    val accessible: Boolean,
    val evidenceSource: String,
    val details: String
)

@Serializable
data class RootAssessment(
    val status: ScanStatus,
    val isRooted: Boolean,
    val summary: String,
    val explanation: String,
    val strongMatches: Int,
    val weakMatches: Int,
    val signals: List<RootSignal>,
    val rootCommandAvailable: Boolean,
    val checkedAtMillis: Long
)

@Serializable
data class RootCommandResult(
    val commandLabel: String,
    val command: String,
    val description: String,
    val executed: Boolean,
    val status: ScanStatus,
    val output: String,
    val error: String? = null,
    val timestampMillis: Long
)

@Serializable
data class InjectionFinding(
    val id: String,
    val detectionName: String,
    val appName: String?,
    val packageName: String,
    val evidenceSource: String,
    val evidenceDetails: String,
    val severity: FindingSeverity,
    val confidence: ConfidenceLevel,
    val timestampMillis: Long,
    val availabilityStatus: EvidenceAvailability,
    val isConfirmedInjection: Boolean
)

@Serializable
data class AppTraceFinding(
    val id: String,
    val appName: String?,
    val packageName: String?,
    val status: EvidenceAvailability,
    val verifiedTraceCount: Int,
    val evidenceSource: String,
    val evidenceDetails: String,
    val locations: List<String>,
    val lastModifiedMillis: Long?,
    val confidence: ConfidenceLevel,
    val suspiciousInjectionFound: Boolean,
    val injectionNote: String
)

@Serializable
data class UnavailableCheck(
    val checkName: String,
    val category: String,
    val reason: String,
    val requiredAction: String? = null
)

@Serializable
data class NetworkDiagnostics(
    val connected: Boolean,
    val transportType: String,
    val pingMs: Double?,
    val jitterMs: Double?,
    val packetLossPercent: Double?,
    val stabilityLabel: String,
    val status: ScanStatus,
    val details: String
)

@Serializable
data class FpsMeasurement(
    val available: Boolean,
    val valueFps: Double? = null,
    val scopeDescription: String,
    val status: ScanStatus
)

@Serializable
data class GamingDiagnosticsSnapshot(
    val cpuModel: String,
    val cpuCores: Int,
    val cpuAbis: List<String>,
    val cpuMaxFreqMhz: Int?,
    val gpuRenderer: String,
    val gpuVendor: String,
    val glEsVersion: String,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val totalStorageGb: Double,
    val availableStorageGb: Double,
    val screenWidthPx: Int,
    val screenHeightPx: Int,
    val refreshRateHz: Float,
    val supportedRefreshRates: List<Float>,
    val androidVersion: String,
    val sdkInt: Int,
    val batteryLevelPercent: Int,
    val batteryTempCelsius: Float?,
    val isCharging: Boolean,
    val thermalStatusLabel: String,
    val thermalAvailable: Boolean,
    val fpsMeasurement: FpsMeasurement,
    val network: NetworkDiagnostics,
    val status: ScanStatus
)

@Serializable
data class FreeFireCompatibilityReport(
    val overallTier: String,
    val status: ScanStatus,
    val compatible: Boolean,
    val recommendedGraphics: String,
    val recommendedFpsSetting: String,
    val checks: List<CompatibilityMetricCheck>,
    val recommendations: List<String>,
    val antiTamperStatement: String
)

@Serializable
data class CompatibilityMetricCheck(
    val name: String,
    val measuredValue: String,
    val status: ScanStatus,
    val note: String
)

@Serializable
data class DeviceSnapshot(
    val manufacturer: String,
    val model: String,
    val brand: String,
    val board: String,
    val androidRelease: String,
    val sdkInt: Int,
    val securityPatch: String,
    val buildTags: String,
    val abiList: List<String>
)

@Serializable
data class AppSettings(
    val rootDiagnosticsConsentGranted: Boolean = false,
    val includeRootInFullScan: Boolean = false,
    val networkProbeHost: String = "1.1.1.1",
    val safTreeUriString: String? = null
)

@Serializable
data class ScanReport(
    val id: String,
    val timestampMillis: Long,
    val overallStatus: ScanStatus,
    val securityStatus: ScanStatus,
    val device: DeviceSnapshot,
    val rootAssessment: RootAssessment,
    val injectionStatus: ScanStatus,
    val injectionFindings: List<InjectionFinding>,
    val traceStatus: ScanStatus,
    val appTraces: List<AppTraceFinding>,
    val gamingDiagnostics: GamingDiagnosticsSnapshot,
    val freeFireReport: FreeFireCompatibilityReport,
    val rootCommandResults: List<RootCommandResult> = emptyList(),
    val unavailableChecks: List<UnavailableCheck>,
    val accessiblePackageCount: Int
)

@Serializable
data class ScanComparison(
    val baselineScanId: String,
    val targetScanId: String,
    val baselineTimestampMillis: Long,
    val targetTimestampMillis: Long,
    val rootStatusChanged: Boolean,
    val injectionDelta: Int,
    val traceDelta: Int,
    val newInjections: List<InjectionFinding>,
    val resolvedInjections: List<InjectionFinding>,
    val newTraces: List<AppTraceFinding>,
    val resolvedTraces: List<AppTraceFinding>,
    val pingDeltaMs: Double?,
    val availableRamDeltaMb: Long
)
