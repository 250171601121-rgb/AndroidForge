package com.tk.checker.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tk.checker.domain.model.EvidenceAvailability
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.ui.components.StatusPill
import com.tk.checker.ui.components.TkKeyValueRow
import com.tk.checker.ui.components.TkSectionCard
import com.tk.checker.ui.components.formatMillis
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.TkUiState

@Composable
fun TraceScannerScreen(
    uiState: TkUiState,
    onSaveSafUri: (android.net.Uri) -> Unit,
    onRescan: () -> Unit
) {
    val context = LocalContext.current
    var uninstalledOnly by remember { mutableStateOf(false) }

    val safLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            onSaveSafUri(uri)
            onRescan()
        }
    }

    val report = uiState.currentReport
    val traces = report?.appTraces.orEmpty().let { list ->
        if (uninstalledOnly) list.filter { it.status == EvidenceAvailability.UNINSTALLED } else list
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TkColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            TkSectionCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("UNIVERSAL APP TRACE SCANNER", style = MaterialTheme.typography.labelMedium, color = TkColors.WarningAmber)
                    StatusPill(status = report?.traceStatus ?: ScanStatus.UNKNOWN)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Detects traces of ANY previously installed app from accessible Android/data, Android/obb, shared storage, UsageStats, and authorized root package registries.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { safLauncher.launch(null) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Select Folder (SAF)", color = TkColors.NeonBlue)
                    }
                    if (!uiState.usageStatsGranted) {
                        Button(
                            onClick = {
                                context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TkColors.NeonPurple, contentColor = Color.White),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Grant Usage Access")
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !uninstalledOnly,
                        onClick = { uninstalledOnly = false },
                        label = { Text("All Traces (${report?.appTraces?.size ?: 0})") }
                    )
                    FilterChip(
                        selected = uninstalledOnly,
                        onClick = { uninstalledOnly = true },
                        label = { Text("Uninstalled Only") }
                    )
                }
            }
        }

        if (report == null) {
            item {
                TkSectionCard {
                    Text("Run SCAN NOW on the Dashboard to inspect accessible historical app traces.", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else if (traces.isEmpty()) {
            item {
                TkSectionCard {
                    val blockedTraces = report.unavailableChecks.filter { it.category == "App Trace Scanner" }
                    if (blockedTraces.isNotEmpty()) {
                        Text("Some Trace Sources Restricted (UNAVAILABLE)", style = MaterialTheme.typography.titleMedium, color = TkColors.WarningAmber)
                        Spacer(Modifier.height(6.dp))
                        blockedTraces.forEach { b ->
                            Text("• ${b.checkName}: ${b.reason}", style = MaterialTheme.typography.bodyMedium)
                        }
                    } else {
                        Text("No leftover uninstalled application traces found in accessible evidence sources.", style = MaterialTheme.typography.titleMedium, color = TkColors.CleanGreen)
                    }
                }
            }
        } else {
            items(traces, key = { it.id }) { trace ->
                val isUninstalled = trace.status == EvidenceAvailability.UNINSTALLED
                TkSectionCard(
                    borderColor = if (isUninstalled) TkColors.WarningAmber.copy(alpha = 0.45f) else TkColors.Border
                ) {
                    Text(
                        text = "${trace.verifiedTraceCount} TRACE${if (trace.verifiedTraceCount > 1) "S" else ""} FOUND",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isUninstalled) TkColors.WarningAmber else TkColors.NeonBlue
                    )
                    Spacer(Modifier.height(6.dp))
                    TkKeyValueRow("App", trace.appName ?: "Unidentifiable")
                    TkKeyValueRow("Package", trace.packageName ?: "Unavailable")
                    TkKeyValueRow(
                        "Status",
                        if (isUninstalled) "UNAVAILABLE / UNINSTALLED" else "INSTALLED",
                        valueColor = if (isUninstalled) TkColors.WarningAmber else TkColors.CleanGreen
                    )
                    TkKeyValueRow("Verified Traces", "${trace.verifiedTraceCount}")
                    TkKeyValueRow("Evidence Source", trace.evidenceSource)
                    TkKeyValueRow("Location", trace.locations.joinToString("\n"))
                    TkKeyValueRow("Last Modified", formatMillis(trace.lastModifiedMillis))
                    TkKeyValueRow("Confidence", trace.confidence.name)
                    TkKeyValueRow(
                        "Injection",
                        trace.injectionNote,
                        valueColor = if (trace.suspiciousInjectionFound) TkColors.DetectedRed else TkColors.CleanGreen
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(trace.evidenceDetails, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}
