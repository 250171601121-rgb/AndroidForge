package com.tk.checker.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tk.checker.domain.model.FindingSeverity
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.ui.theme.TkColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun statusColor(status: ScanStatus): Color = when (status) {
    ScanStatus.CLEAN -> TkColors.CleanGreen
    ScanStatus.WARNING -> TkColors.WarningAmber
    ScanStatus.DETECTED -> TkColors.DetectedRed
    ScanStatus.UNAVAILABLE -> TkColors.UnavailableSlate
    ScanStatus.UNKNOWN -> TkColors.UnavailableSlate
}

fun severityColor(severity: FindingSeverity): Color = when (severity) {
    FindingSeverity.INFO -> TkColors.NeonBlue
    FindingSeverity.LOW -> TkColors.CleanGreen
    FindingSeverity.MEDIUM -> TkColors.WarningAmber
    FindingSeverity.HIGH -> Color(0xFFF97316)
    FindingSeverity.CRITICAL -> TkColors.DetectedRed
}

fun formatMillis(millis: Long?): String {
    if (millis == null || millis <= 0L) return "Unknown"
    return SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.US).format(Date(millis))
}

@Composable
fun TkShieldLogo(size: Dp = 44.dp, animated: Boolean = false) {
    val transition = rememberInfiniteTransition(label = "tk_shield")
    val pulse by transition.animateFloat(
        initialValue = 0.65f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val glowAlpha = if (animated) pulse else 0.9f

    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val outer = Path().apply {
            moveTo(w * 0.5f, h * 0.06f)
            lineTo(w * 0.9f, h * 0.22f)
            lineTo(w * 0.9f, h * 0.52f)
            cubicTo(w * 0.9f, h * 0.74f, w * 0.72f, h * 0.88f, w * 0.5f, h * 0.95f)
            cubicTo(w * 0.28f, h * 0.88f, w * 0.1f, h * 0.74f, w * 0.1f, h * 0.52f)
            lineTo(w * 0.1f, h * 0.22f)
            close()
        }
        drawPath(
            path = outer,
            color = TkColors.SurfaceElevated
        )
        drawPath(
            path = outer,
            brush = Brush.linearGradient(
                colors = listOf(
                    TkColors.NeonBlue.copy(alpha = glowAlpha),
                    TkColors.NeonPurple.copy(alpha = glowAlpha)
                ),
                start = Offset.Zero,
                end = Offset(w, h)
            ),
            style = Stroke(width = w * 0.055f, cap = StrokeCap.Round)
        )
        // Stylized "T" crest bar
        drawLine(
            color = TkColors.NeonBlue,
            start = Offset(w * 0.32f, h * 0.39f),
            end = Offset(w * 0.68f, h * 0.39f),
            strokeWidth = w * 0.07f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = TkColors.NeonBlue,
            start = Offset(w * 0.5f, h * 0.39f),
            end = Offset(w * 0.5f, h * 0.72f),
            strokeWidth = w * 0.07f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun StatusPill(status: ScanStatus, modifier: Modifier = Modifier) {
    val color = statusColor(status)
    Surface(
        modifier = modifier,
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Text(
            text = status.name,
            color = color,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun TkSectionCard(
    modifier: Modifier = Modifier,
    borderColor: Color = TkColors.Border,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val baseModifier = modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }

    Card(
        modifier = baseModifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = TkColors.Surface),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun TkKeyValueRow(label: String, value: String, valueColor: Color = TkColors.TextPrimary) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = TkColors.TextSecondary,
            modifier = Modifier.weight(0.42f)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium
            ),
            color = valueColor,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(0.58f)
        )
    }
}

@Composable
fun ModuleTileCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    status: ScanStatus?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    TkSectionCard(
        modifier = modifier,
        borderColor = accent.copy(alpha = 0.28f),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(accent.copy(alpha = 0.14f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(20.dp))
            }
            if (status != null) {
                StatusPill(status = status)
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
