package com.tk.checker.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tk.checker.data.repository.ReportExporter
import com.tk.checker.data.repository.ScanRepository
import com.tk.checker.data.scanner.FreeFireAnalyzer
import com.tk.checker.data.scanner.GamingDiagnosticsEngine
import com.tk.checker.data.scanner.InjectionScanner
import com.tk.checker.data.scanner.RootDetector
import com.tk.checker.data.scanner.RootDiagnosticsEngine
import com.tk.checker.data.scanner.TraceScanner
import com.tk.checker.domain.model.AppSettings
import com.tk.checker.domain.model.DeviceSnapshot
import com.tk.checker.domain.model.RootCommandResult
import com.tk.checker.domain.model.ScanComparison
import com.tk.checker.domain.model.ScanReport
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.domain.model.UnavailableCheck
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

data class TkUiState(
    val isScanning: Boolean = false,
    val scanProgress: Float = 0f,
    val scanStageLabel: String = "Ready",
    val currentReport: ScanReport? = null,
    val history: List<ScanReport> = emptyList(),
    val comparison: ScanComparison? = null,
    val settings: AppSettings = AppSettings(),
    val rootCommandResults: List<RootCommandResult> = emptyList(),
    val isRunningRootDiagnostics: Boolean = false,
    val usageStatsGranted: Boolean = false,
    val exportMessage: String? = null,
    val errorMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val repository = ScanRepository(appContext)
    private val exporter = ReportExporter(appContext)
    private val rootDetector = RootDetector(appContext)
    private val rootEngine = RootDiagnosticsEngine()
    private val injectionScanner = InjectionScanner(appContext)
    private val traceScanner = TraceScanner(appContext)
    private val gamingEngine = GamingDiagnosticsEngine(appContext)
    private val freeFireAnalyzer = FreeFireAnalyzer()

    private val _uiState = MutableStateFlow(
        TkUiState(
            history = repository.loadHistory(),
            currentReport = repository.loadHistory().firstOrNull(),
            settings = repository.loadSettings(),
            usageStatsGranted = traceScanner.hasUsageStatsPermission()
        )
    )
    val uiState: StateFlow<TkUiState> = _uiState.asStateFlow()

    val rootCommandSpecs = rootEngine.whitelistedReadOnlyCommands

    fun refreshPermissions() {
        _uiState.update {
            it.copy(usageStatsGranted = traceScanner.hasUsageStatsPermission())
        }
    }

    fun runFullScan() {
        if (_uiState.value.isScanning) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isScanning = true,
                    scanProgress = 0.08f,
                    scanStageLabel = "Inspecting device & root indicators...",
                    errorMessage = null,
                    exportMessage = null
                )
            }

            runCatching {
                val device = withContext(Dispatchers.IO) { readDeviceSnapshot() }
                val rootAssessment = withContext(Dispatchers.IO) { rootDetector.detect() }

                _uiState.update {
                    it.copy(scanProgress = 0.28f, scanStageLabel = "Scanning packages & injection vectors...")
                }

                val injectionOutput = withContext(Dispatchers.IO) { injectionScanner.scan() }

                var rootCmdResults = _uiState.value.rootCommandResults
                if (_uiState.value.settings.includeRootInFullScan &&
                    _uiState.value.settings.rootDiagnosticsConsentGranted &&
                    rootAssessment.rootCommandAvailable
                ) {
                    _uiState.update {
                        it.copy(scanProgress = 0.45f, scanStageLabel = "Running read-only root diagnostics...")
                    }
                    rootCmdResults = rootEngine.executeReadOnlyDiagnostics(
                        consentGranted = true,
                        rootAvailable = rootAssessment.rootCommandAvailable
                    )
                }

                _uiState.update {
                    it.copy(scanProgress = 0.62f, scanStageLabel = "Scanning accessible app & deleted traces...")
                }

                val installedMap = withContext(Dispatchers.IO) { loadInstalledPackageMap() }
                val traceOutput = withContext(Dispatchers.IO) {
                    traceScanner.scan(
                        installedPackages = installedMap,
                        injectionFindings = injectionOutput.findings,
                        safTreeUriString = _uiState.value.settings.safTreeUriString,
                        rootCommandResults = rootCmdResults
                    )
                }

                _uiState.update {
                    it.copy(scanProgress = 0.82f, scanStageLabel = "Benchmarking hardware, thermal & network latency...")
                }

                val gamingSnapshot = gamingEngine.collect(_uiState.value.settings.networkProbeHost)
                val ffReport = freeFireAnalyzer.evaluate(gamingSnapshot)

                val allUnavailable = (injectionOutput.unavailableChecks + traceOutput.unavailableChecks).toMutableList()
                if (!gamingSnapshot.fpsMeasurement.available) {
                    allUnavailable += UnavailableCheck(
                        checkName = "Cross-App Game FPS Monitor",
                        category = "Gaming Diagnostics",
                        reason = gamingSnapshot.fpsMeasurement.scopeDescription
                    )
                }
                if (!gamingSnapshot.thermalAvailable) {
                    allUnavailable += UnavailableCheck(
                        checkName = "Android Thermal Status API",
                        category = "Gaming Diagnostics",
                        reason = gamingSnapshot.thermalStatusLabel
                    )
                }

                val securityStatus = combineStatuses(
                    listOf(rootAssessment.status, injectionOutput.status)
                )
                val overallStatus = combineStatuses(
                    listOf(securityStatus, traceOutput.status, gamingSnapshot.status)
                )

                val report = ScanReport(
                    id = UUID.randomUUID().toString(),
                    timestampMillis = System.currentTimeMillis(),
                    overallStatus = overallStatus,
                    securityStatus = securityStatus,
                    device = device,
                    rootAssessment = rootAssessment,
                    injectionStatus = injectionOutput.status,
                    injectionFindings = injectionOutput.findings,
                    traceStatus = traceOutput.status,
                    appTraces = traceOutput.traces,
                    gamingDiagnostics = gamingSnapshot,
                    freeFireReport = ffReport,
                    rootCommandResults = rootCmdResults,
                    unavailableChecks = allUnavailable,
                    accessiblePackageCount = injectionOutput.inspectedPackageCount
                )

                val updatedHistory = withContext(Dispatchers.IO) {
                    repository.saveScan(report)
                }

                _uiState.update {
                    it.copy(
                        isScanning = false,
                        scanProgress = 1f,
                        scanStageLabel = "Scan complete",
                        currentReport = report,
                        history = updatedHistory,
                        rootCommandResults = rootCmdResults,
                        usageStatsGranted = traceScanner.hasUsageStatsPermission()
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isScanning = false,
                        scanProgress = 0f,
                        scanStageLabel = "Scan failed",
                        errorMessage = err.message ?: "Unexpected diagnostic error"
                    )
                }
            }
        }
    }

    fun grantRootConsentAndRun(grantConsent: Boolean) {
        val updatedSettings = _uiState.value.settings.copy(
            rootDiagnosticsConsentGranted = grantConsent
        )
        repository.saveSettings(updatedSettings)
        _uiState.update { it.copy(settings = updatedSettings) }

        if (grantConsent) {
            runReadOnlyRootDiagnostics()
        } else {
            _uiState.update { it.copy(rootCommandResults = emptyList()) }
        }
    }

    fun runReadOnlyRootDiagnostics() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRunningRootDiagnostics = true) }
            val rootAssessment = _uiState.value.currentReport?.rootAssessment
                ?: withContext(Dispatchers.IO) { rootDetector.detect() }

            val results = rootEngine.executeReadOnlyDiagnostics(
                consentGranted = _uiState.value.settings.rootDiagnosticsConsentGranted,
                rootAvailable = rootAssessment.rootCommandAvailable
            )
            _uiState.update {
                it.copy(
                    isRunningRootDiagnostics = false,
                    rootCommandResults = results
                )
            }
        }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val updated = transform(_uiState.value.settings)
        repository.saveSettings(updated)
        _uiState.update { it.copy(settings = updated) }
    }

    fun saveSafTreeUri(uri: Uri) {
        runCatching {
            appContext.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        updateSettings { it.copy(safTreeUriString = uri.toString()) }
    }

    fun selectReport(report: ScanReport) {
        _uiState.update { it.copy(currentReport = report) }
    }

    fun compareReports(baseline: ScanReport, target: ScanReport) {
        _uiState.update {
            it.copy(comparison = ScanRepository.compareScans(baseline, target))
        }
    }

    fun clearComparison() {
        _uiState.update { it.copy(comparison = null) }
    }

    fun deleteScan(scanId: String) {
        val updated = repository.deleteScan(scanId)
        _uiState.update { state ->
            val current = if (state.currentReport?.id == scanId) updated.firstOrNull() else state.currentReport
            state.copy(history = updated, currentReport = current)
        }
    }

    fun clearAllHistory() {
        repository.clearAllHistory()
        _uiState.update {
            it.copy(history = emptyList(), currentReport = null, comparison = null)
        }
    }

    fun exportReportUri(report: ScanReport, asPdf: Boolean): Uri? {
        return runCatching {
            val uri = if (asPdf) exporter.exportPdf(report) else exporter.exportTxt(report)
            _uiState.update {
                it.copy(exportMessage = if (asPdf) "PDF report generated" else "TXT report generated")
            }
            uri
        }.getOrElse { err ->
            _uiState.update { it.copy(errorMessage = "Export failed: ${err.message}") }
            null
        }
    }

    fun clearMessages() {
        _uiState.update { it.copy(exportMessage = null, errorMessage = null) }
    }

    private fun readDeviceSnapshot(): DeviceSnapshot {
        val patch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Build.VERSION.SECURITY_PATCH
        } else {
            "Unknown"
        }
        return DeviceSnapshot(
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercaseChar() },
            model = Build.MODEL,
            brand = Build.BRAND,
            board = Build.BOARD,
            androidRelease = Build.VERSION.RELEASE,
            sdkInt = Build.VERSION.SDK_INT,
            securityPatch = patch,
            buildTags = Build.TAGS.orEmpty(),
            abiList = Build.SUPPORTED_ABIS.toList()
        )
    }

    private fun loadInstalledPackageMap(): Map<String, String?> {
        val pm = appContext.packageManager
        val list = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(0)
            }
        }.getOrDefault(emptyList())

        return list.associate { info ->
            val label = info.applicationInfo?.let {
                runCatching { pm.getApplicationLabel(it).toString() }.getOrNull()
            }
            info.packageName to label
        }
    }

    companion object {
        fun combineStatuses(statuses: List<ScanStatus>): ScanStatus {
            return when {
                ScanStatus.DETECTED in statuses -> ScanStatus.DETECTED
                ScanStatus.WARNING in statuses -> ScanStatus.WARNING
                statuses.all { it == ScanStatus.UNAVAILABLE } -> ScanStatus.UNAVAILABLE
                ScanStatus.UNAVAILABLE in statuses -> ScanStatus.WARNING
                ScanStatus.UNKNOWN in statuses -> ScanStatus.UNKNOWN
                else -> ScanStatus.CLEAN
            }
        }
    }
}
