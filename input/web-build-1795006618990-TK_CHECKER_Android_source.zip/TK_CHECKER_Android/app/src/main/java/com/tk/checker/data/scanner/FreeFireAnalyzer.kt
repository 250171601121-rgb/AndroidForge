package com.tk.checker.data.scanner

import com.tk.checker.domain.model.CompatibilityMetricCheck
import com.tk.checker.domain.model.FreeFireCompatibilityReport
import com.tk.checker.domain.model.GamingDiagnosticsSnapshot
import com.tk.checker.domain.model.ScanStatus

/**
 * Evaluates Garena Free Fire / Free Fire MAX compatibility based strictly on
 * measured hardware and network diagnostics. Never modifies, injects, or touches game files.
 */
class FreeFireAnalyzer {

    fun evaluate(diag: GamingDiagnosticsSnapshot): FreeFireCompatibilityReport {
        val checks = mutableListOf<CompatibilityMetricCheck>()
        val recommendations = mutableListOf<String>()

        // 1. RAM check (Min ~2GB for Free Fire, 4GB+ recommended, 6GB+ for MAX High/Ultra)
        val ramStatus = when {
            diag.totalRamMb >= 5500 -> ScanStatus.CLEAN
            diag.totalRamMb >= 3500 -> ScanStatus.CLEAN
            diag.totalRamMb >= 1800 -> ScanStatus.WARNING
            else -> ScanStatus.DETECTED
        }
        checks += CompatibilityMetricCheck(
            name = "System RAM",
            measuredValue = "${diag.totalRamMb} MB total (${diag.availableRamMb} MB free)",
            status = ramStatus,
            note = when (ramStatus) {
                ScanStatus.CLEAN -> "Sufficient memory headroom for smooth asset streaming."
                ScanStatus.WARNING -> "Close background apps before launching to prevent out-of-memory stutters."
                else -> "Below recommended 2 GB RAM baseline; expect aggressive background reloads."
            }
        )
        if (diag.availableRamMb < 1200) {
            recommendations += "Free up background RAM (currently ${diag.availableRamMb} MB available) before queuing ranked matches."
        }

        // 2. Storage headroom
        val storageStatus = when {
            diag.availableStorageGb >= 6.0 -> ScanStatus.CLEAN
            diag.availableStorageGb >= 2.5 -> ScanStatus.WARNING
            else -> ScanStatus.DETECTED
        }
        checks += CompatibilityMetricCheck(
            name = "Available Storage",
            measuredValue = "${diag.availableStorageGb} GB free / ${diag.totalStorageGb} GB",
            status = storageStatus,
            note = if (storageStatus == ScanStatus.CLEAN) {
                "Adequate space for game patches and expansion map packs."
            } else {
                "Low storage can degrade NAND flash write speeds and shader caching."
            }
        )
        if (storageStatus != ScanStatus.CLEAN) {
            recommendations += "Keep at least 6 GB free storage for Free Fire HD expansion packs and cache."
        }

        // 3. CPU & ABI
        val has64Bit = diag.cpuAbis.any { it.contains("64") }
        val cpuStatus = when {
            has64Bit && diag.cpuCores >= 6 -> ScanStatus.CLEAN
            diag.cpuCores >= 4 -> ScanStatus.WARNING
            else -> ScanStatus.DETECTED
        }
        checks += CompatibilityMetricCheck(
            name = "CPU Architecture",
            measuredValue = "${diag.cpuModel} (${diag.cpuCores} cores, ${diag.cpuAbis.firstOrNull() ?: "unknown"})",
            status = cpuStatus,
            note = if (has64Bit) "64-bit ARMv8/x86_64 execution supported." else "32-bit only ABI may limit performance."
        )

        // 4. GPU capability
        val gpuStatus = if (diag.gpuRenderer == "UNAVAILABLE") ScanStatus.UNAVAILABLE else ScanStatus.CLEAN
        checks += CompatibilityMetricCheck(
            name = "GPU Renderer",
            measuredValue = "${diag.gpuRenderer} (GLES ${diag.glEsVersion})",
            status = gpuStatus,
            note = if (gpuStatus == ScanStatus.CLEAN) "Hardware OpenGL ES pipeline active." else "GPU renderer string unavailable."
        )

        // 5. Refresh rate
        val hzStatus = if (diag.refreshRateHz >= 89f) ScanStatus.CLEAN else ScanStatus.CLEAN
        checks += CompatibilityMetricCheck(
            name = "Display Refresh Rate",
            measuredValue = "${diag.refreshRateHz.toInt()} Hz",
            status = hzStatus,
            note = if (diag.refreshRateHz >= 89f) {
                "High-refresh panel detected; High FPS mode supported where thermal headroom permits."
            } else {
                "Standard 60 Hz display panel."
            }
        )

        // 6. Thermal condition
        val thermalStatus = when {
            !diag.thermalAvailable -> ScanStatus.UNAVAILABLE
            diag.thermalStatusLabel.startsWith("NORMAL") || diag.thermalStatusLabel.startsWith("LIGHT") -> ScanStatus.CLEAN
            else -> ScanStatus.WARNING
        }
        checks += CompatibilityMetricCheck(
            name = "Thermal Condition",
            measuredValue = diag.thermalStatusLabel,
            status = thermalStatus,
            note = if (thermalStatus == ScanStatus.WARNING) {
                "Device is already warm; prolonged High/Max graphics will trigger clock throttling."
            } else if (thermalStatus == ScanStatus.UNAVAILABLE) {
                "Thermal API unavailable on Android ${diag.androidVersion}."
            } else {
                "Thermal headroom is nominal."
            }
        )
        if (thermalStatus == ScanStatus.WARNING) {
            recommendations += "Lower shadow quality or pause charging while playing to reduce thermal throttling."
        }

        // 7. Network stability
        checks += CompatibilityMetricCheck(
            name = "Network Stability",
            measuredValue = diag.network.pingMs?.let { "${it} ms (${diag.network.stabilityLabel})" } ?: diag.network.stabilityLabel,
            status = diag.network.status,
            note = diag.network.details
        )
        if (diag.network.status != ScanStatus.CLEAN) {
            recommendations += "Switch to 5 GHz Wi-Fi or stable low-jitter cellular before competitive play."
        }

        val (tier, graphics, fpsSetting) = when {
            diag.totalRamMb >= 5500 && diag.cpuCores >= 8 && diag.refreshRateHz >= 89f -> {
                Triple("HIGH / ULTRA READY", "Ultra / High (Shadows Optional)", "High FPS")
            }
            diag.totalRamMb >= 3500 && diag.cpuCores >= 6 -> {
                Triple("STANDARD / HIGH READY", "Standard or High", "High FPS (Monitor Heat)")
            }
            diag.totalRamMb >= 1800 -> {
                Triple("SMOOTH PROFILE RECOMMENDED", "Smooth", "Normal (60 FPS Cap)")
            }
            else -> {
                Triple("ENTRY / CONSTRAINED", "Smooth (Disable HD Packs)", "Normal")
            }
        }

        if (recommendations.isEmpty()) {
            recommendations += "Hardware and network checks are nominal for $tier ($graphics, $fpsSetting)."
        }

        val overallStatus = when {
            checks.any { it.status == ScanStatus.DETECTED } -> ScanStatus.WARNING
            checks.any { it.status == ScanStatus.WARNING } -> ScanStatus.WARNING
            else -> ScanStatus.CLEAN
        }

        return FreeFireCompatibilityReport(
            overallTier = tier,
            status = overallStatus,
            compatible = diag.totalRamMb >= 1500 && diag.availableStorageGb >= 1.5,
            recommendedGraphics = graphics,
            recommendedFpsSetting = fpsSetting,
            checks = checks,
            recommendations = recommendations,
            antiTamperStatement = "Read-only hardware compatibility evaluation. TK CHECKER never modifies Free Fire files, accesses game memory, or interacts with anti-cheat."
        )
    }
}
