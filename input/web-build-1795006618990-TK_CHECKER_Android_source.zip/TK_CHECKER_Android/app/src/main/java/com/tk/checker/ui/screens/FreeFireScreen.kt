package com.tk.checker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.ui.components.StatusPill
import com.tk.checker.ui.components.TkKeyValueRow
import com.tk.checker.ui.components.TkSectionCard
import com.tk.checker.ui.components.statusColor
import com.tk.checker.ui.theme.TkColors
import com.tk.checker.ui.viewmodel.TkUiState

@Composable
fun FreeFireScreen(uiState: TkUiState) {
    val ff = uiState.currentReport?.freeFireReport

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TkColors.Background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (ff == null) {
            item {
                TkSectionCard {
                    Text("Free Fire Compatibility", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text("Run SCAN NOW on the Dashboard to evaluate CPU, GPU, RAM, storage, refresh rate, thermal headroom, and network latency.", style = MaterialTheme.typography.bodyMedium)
                }
            }
            return@LazyColumn
        }

        item {
            TkSectionCard(borderColor = statusColor(ff.status).copy(alpha = 0.45f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("FREE FIRE COMPATIBILITY", style = MaterialTheme.typography.labelMedium, color = TkColors.CleanGreen)
                    StatusPill(status = ff.status)
                }
                Spacer(Modifier.height(10.dp))
                TkKeyValueRow("Readiness Tier", ff.overallTier, valueColor = TkColors.NeonBlue)
                TkKeyValueRow("Compatible", if (ff.compatible) "YES" else "LIMITED")
                TkKeyValueRow("Suggested Graphics", ff.recommendedGraphics)
                TkKeyValueRow("Suggested FPS Cap", ff.recommendedFpsSetting)
            }
        }

        item {
            Text("MEASURED HARDWARE CHECKS", style = MaterialTheme.typography.labelMedium, color = TkColors.TextSecondary)
        }

        items(ff.checks) { check ->
            TkSectionCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(check.name, style = MaterialTheme.typography.titleMedium)
                    StatusPill(status = check.status)
                }
                Spacer(Modifier.height(4.dp))
                Text(check.measuredValue, style = MaterialTheme.typography.labelMedium, color = TkColors.NeonBlue)
                Spacer(Modifier.height(4.dp))
                Text(check.note, style = MaterialTheme.typography.bodyMedium)
            }
        }

        item {
            TkSectionCard(borderColor = TkColors.NeonPurple.copy(alpha = 0.4f)) {
                Text("PERFORMANCE RECOMMENDATIONS", style = MaterialTheme.typography.labelMedium, color = TkColors.NeonPurple)
                Spacer(Modifier.height(8.dp))
                ff.recommendations.forEach { rec ->
                    Text("• $rec", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    ff.antiTamperStatement,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TkColors.CleanGreen
                )
            }
        }
    }
}
