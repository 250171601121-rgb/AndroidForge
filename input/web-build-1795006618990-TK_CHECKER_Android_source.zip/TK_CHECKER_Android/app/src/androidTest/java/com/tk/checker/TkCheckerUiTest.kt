package com.tk.checker

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import org.junit.Rule
import org.junit.Test

class TkCheckerUiTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun dashboardLoadsAndNavigatesToModules() {
        composeRule.onNodeWithText("TK CHECKER").assertIsDisplayed()
        composeRule.onNodeWithText("SCAN NOW").assertIsDisplayed()

        composeRule.onNodeWithText("ROOT PANEL").performClick()
        composeRule.onNodeWithText("ROOT VERIFICATION STATUS").assertIsDisplayed()

        composeRule.onNodeWithText("Home").performClick()
        composeRule.onNodeWithText("SETTINGS").performClick()
        composeRule.onNodeWithText("PRIVACY & ZERO-TELEMETRY GUARANTEE").assertIsDisplayed()
    }
}
