package com.tk.checker

import com.tk.checker.data.scanner.TraceScanner
import com.tk.checker.domain.model.ConfidenceLevel
import com.tk.checker.domain.model.EvidenceAvailability
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.domain.model.UnavailableCheck
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TraceScannerTest {

    @Test
    fun universalAggregation_deduplicatesSameAppAndMarksUninstalled() {
        val raw = listOf(
            TraceScanner.RawTraceEvidence(
                key = "com.example.zrex",
                appName = "ZREX",
                packageName = "com.example.zrex",
                evidenceSource = "Leftover Android/data folder",
                evidenceDetails = "Folder found",
                location = "/storage/emulated/0/Android/data/com.example.zrex",
                lastModifiedMillis = 1700000000000L,
                confidence = ConfidenceLevel.HIGH,
                isPackageScoped = true
            ),
            TraceScanner.RawTraceEvidence(
                key = "com.example.zrex",
                appName = "ZREX",
                packageName = "com.example.zrex",
                evidenceSource = "Android Usage History",
                evidenceDetails = "Usage record found",
                location = "UsageStats/com.example.zrex",
                lastModifiedMillis = 1700005000000L,
                confidence = ConfidenceLevel.HIGH,
                isPackageScoped = true
            ),
            TraceScanner.RawTraceEvidence(
                key = "org.other.deletedapp",
                appName = null,
                packageName = "org.other.deletedapp",
                evidenceSource = "Leftover Android/obb folder",
                evidenceDetails = "OBB folder found",
                location = "/storage/emulated/0/Android/obb/org.other.deletedapp",
                lastModifiedMillis = 1690000000000L,
                confidence = ConfidenceLevel.MEDIUM,
                isPackageScoped = true
            )
        )

        val traces = TraceScanner.aggregateEvidence(
            rawEvidence = raw,
            installedPackages = emptyMap(),
            injectionFindings = emptyList()
        )

        assertEquals(2, traces.size)
        val zrex = traces.first { it.packageName == "com.example.zrex" }
        assertEquals(EvidenceAvailability.UNINSTALLED, zrex.status)
        assertEquals(2, zrex.verifiedTraceCount)
        assertEquals(ConfidenceLevel.HIGH, zrex.confidence)
        assertFalse(zrex.suspiciousInjectionFound)
        assertEquals("NOT CONFIRMED", zrex.injectionNote)

        val other = traces.first { it.packageName == "org.other.deletedapp" }
        assertEquals(EvidenceAvailability.UNINSTALLED, other.status)
        assertEquals("Deletedapp", other.appName)
    }

    @Test
    fun genericFolderNames_rejectedAsPackageIdentifiers() {
        assertFalse(TraceScanner.isValidPackageLikeName("Downloads"))
        assertFalse(TraceScanner.isValidPackageLikeName("MyFolder"))
        assertTrue(TraceScanner.isValidPackageLikeName("com.vendor.game"))
    }

    @Test
    fun blockedTraceSources_neverReportClean() {
        val status = TraceScanner.determineTraceStatus(
            traces = emptyList(),
            unavailableChecks = listOf(UnavailableCheck("Android/data", "App Trace Scanner", "Scoped storage")),
            accessibleSourcesCount = 0
        )
        assertEquals(ScanStatus.UNAVAILABLE, status)
    }
}
