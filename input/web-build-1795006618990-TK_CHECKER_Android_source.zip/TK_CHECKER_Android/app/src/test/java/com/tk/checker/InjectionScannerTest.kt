package com.tk.checker

import com.tk.checker.data.scanner.InjectionScanner
import com.tk.checker.domain.model.FindingSeverity
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.domain.model.UnavailableCheck
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class InjectionScannerTest {

    @Test
    fun ordinaryPlayStoreApps_produceZeroFalsePositives() {
        val normalApps = listOf(
            InjectionScanner.PackageInspectionInput(
                packageName = "com.dts.freefireth",
                appName = "Free Fire",
                isSystemApp = false,
                isDebuggable = false,
                isTestOnly = false,
                sourceDir = "/data/app/~~abc/com.dts.freefireth/base.apk",
                nativeLibraryFiles = listOf("libil2cpp.so", "libunity.so"),
                installerPackage = "com.android.vending",
                hasOverlayGranted = false,
                hasAccessibilityEnabled = false,
                hasSigningMismatchOrUnsigned = false
            ),
            InjectionScanner.PackageInspectionInput(
                packageName = "com.whatsapp",
                appName = "WhatsApp",
                isSystemApp = false,
                isDebuggable = false,
                isTestOnly = false,
                sourceDir = "/data/app/~~xyz/com.whatsapp/base.apk",
                nativeLibraryFiles = listOf("libwhatsapp.so"),
                installerPackage = "com.android.vending",
                hasOverlayGranted = true,
                hasAccessibilityEnabled = false,
                hasSigningMismatchOrUnsigned = false
            )
        )
        val findings = InjectionScanner.analyzePackages(normalApps)
        assertTrue(findings.isEmpty())
    }

    @Test
    fun suspiciousNativeLibAndHookingTool_detectedAndConfirmed() {
        val inputs = listOf(
            InjectionScanner.PackageInspectionInput(
                packageName = "org.lsposed.manager",
                appName = "LSPosed",
                isSystemApp = false,
                isDebuggable = false,
                isTestOnly = false,
                sourceDir = "/data/app/org.lsposed.manager/base.apk",
                nativeLibraryFiles = listOf("libfrida-gadget.so"),
                installerPackage = null,
                hasOverlayGranted = true,
                hasAccessibilityEnabled = false,
                hasSigningMismatchOrUnsigned = false
            )
        )
        val findings = InjectionScanner.analyzePackages(inputs)
        assertTrue(findings.any { it.isConfirmedInjection && it.severity == FindingSeverity.CRITICAL })
        assertEquals(
            ScanStatus.DETECTED,
            InjectionScanner.determineOverallStatus(findings, emptyList(), 1)
        )
    }

    @Test
    fun sideloadedDebuggableOnly_isSuspiciousIndicatorNotConfirmed() {
        val inputs = listOf(
            InjectionScanner.PackageInspectionInput(
                packageName = "com.custom.utility",
                appName = "Custom Utility",
                isSystemApp = false,
                isDebuggable = true,
                isTestOnly = false,
                sourceDir = "/data/app/com.custom.utility/base.apk",
                nativeLibraryFiles = emptyList(),
                installerPackage = null,
                hasOverlayGranted = false,
                hasAccessibilityEnabled = false,
                hasSigningMismatchOrUnsigned = false
            )
        )
        val findings = InjectionScanner.analyzePackages(inputs)
        assertEquals(1, findings.size)
        assertFalse(findings.first().isConfirmedInjection)
        assertEquals(
            ScanStatus.WARNING,
            InjectionScanner.determineOverallStatus(findings, emptyList(), 1)
        )
    }

    @Test
    fun zeroInspectedPackagesWithBlockedChecks_returnsUnavailable() {
        val status = InjectionScanner.determineOverallStatus(
            findings = emptyList(),
            unavailableChecks = listOf(UnavailableCheck("Package Scan", "Injection", "Blocked")),
            inspectedPackageCount = 0
        )
        assertEquals(ScanStatus.UNAVAILABLE, status)
    }
}
