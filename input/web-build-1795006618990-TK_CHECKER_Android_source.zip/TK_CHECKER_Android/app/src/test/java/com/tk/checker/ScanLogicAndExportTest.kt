package com.tk.checker

import com.tk.checker.data.repository.ReportExporter
import com.tk.checker.data.repository.ScanRepository
import com.tk.checker.data.scanner.FreeFireAnalyzer
import com.tk.checker.domain.model.DeviceSnapshot
import com.tk.checker.domain.model.FpsMeasurement
import com.tk.checker.domain.model.GamingDiagnosticsSnapshot
import com.tk.checker.domain.model.NetworkDiagnostics
import com.tk.checker.domain.model.RootAssessment
import com.tk.checker.domain.model.ScanReport
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.domain.model.UnavailableCheck
import com.tk.checker.ui.viewmodel.MainViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScanLogicAndExportTest {

    private fun sampleGamingSnapshot(ramMb: Long = 8192L): GamingDiagnosticsSnapshot {
        return GamingDiagnosticsSnapshot(
            cpuModel = "Snapdragon 8 Gen 2",
            cpuCores = 8,
            cpuAbis = listOf("arm64-v8a"),
            cpuMaxFreqMhz = 3200,
            gpuRenderer = "Adreno (TM) 740",
            gpuVendor = "Qualcomm",
            glEsVersion = "3.2",
            totalRamMb = ramMb,
            availableRamMb = ramMb / 2,
            totalStorageGb = 128.0,
            availableStorageGb = 42.5,
            screenWidthPx = 1080,
            screenHeightPx = 2400,
            refreshRateHz = 120f,
            supportedRefreshRates = listOf(60f, 120f),
            androidVersion = "14",
            sdkInt = 34,
            batteryLevelPercent = 82,
            batteryTempCelsius = 33.4f,
            isCharging = false,
            thermalStatusLabel = "NORMAL (No Throttling)",
            thermalAvailable = true,
            fpsMeasurement = FpsMeasurement(false, null, "FPS MONITORING UNAVAILABLE", ScanStatus.UNAVAILABLE),
            network = NetworkDiagnostics(true, "Wi-Fi", 24.5, 3.1, 0.0, "STABLE", ScanStatus.CLEAN, "OK"),
            status = ScanStatus.CLEAN
        )
    }

    @Test
    fun combineStatuses_neverMasksUnavailableAsClean() {
        assertEquals(
            ScanStatus.WARNING,
            MainViewModel.combineStatuses(listOf(ScanStatus.CLEAN, ScanStatus.UNAVAILABLE))
        )
        assertEquals(
            ScanStatus.UNAVAILABLE,
            MainViewModel.combineStatuses(listOf(ScanStatus.UNAVAILABLE, ScanStatus.UNAVAILABLE))
        )
        assertEquals(
            ScanStatus.DETECTED,
            MainViewModel.combineStatuses(listOf(ScanStatus.CLEAN, ScanStatus.DETECTED, ScanStatus.WARNING))
        )
    }

    @Test
    fun freeFireAnalyzer_evaluatesHighEndAndIncludesNonTamperStatement() {
        val analyzer = FreeFireAnalyzer()
        val report = analyzer.evaluate(sampleGamingSnapshot(8192L))
        assertTrue(report.compatible)
        assertEquals("HIGH / ULTRA READY", report.overallTier)
        assertTrue(report.antiTamperStatement.contains("never modifies Free Fire"))
    }

    @Test
    fun reportExportAndComparison_includeUnavailableChecksAndDeltas() {
        val gaming = sampleGamingSnapshot(8192L)
        val ff = FreeFireAnalyzer().evaluate(gaming)
        val root = RootAssessment(ScanStatus.CLEAN, false, "Clean", "None", 0, 0, emptyList(), false, 1000L)
        val device = DeviceSnapshot("Google", "Pixel", "google", "husky", "14", 34, "2025-01-05", "release-keys", listOf("arm64-v8a"))

        val r1 = ScanReport(
            id = "scan-1",
            timestampMillis = 1000L,
            overallStatus = ScanStatus.WARNING,
            securityStatus = ScanStatus.CLEAN,
            device = device,
            rootAssessment = root,
            injectionStatus = ScanStatus.CLEAN,
            injectionFindings = emptyList(),
            traceStatus = ScanStatus.UNAVAILABLE,
            appTraces = emptyList(),
            gamingDiagnostics = gaming,
            freeFireReport = ff,
            unavailableChecks = listOf(UnavailableCheck("Cross-App FPS", "Gaming", "FPS MONITORING UNAVAILABLE")),
            accessiblePackageCount = 120
        )

        val r2 = r1.copy(
            id = "scan-2",
            timestampMillis = 2000L,
            gamingDiagnostics = gaming.copy(availableRamMb = 3500L)
        )

        val diff = ScanRepository.compareScans(r1, r2)
        assertEquals(-596L, diff.availableRamDeltaMb)

        val txt = ReportExporter.buildTxtReport(r1)
        assertTrue(txt.contains("TK CHECKER"))
        assertTrue(txt.contains("FPS MONITORING UNAVAILABLE"))
        assertTrue(txt.contains("UNAVAILABLE / ANDROID-RESTRICTED CHECKS"))
    }
}
