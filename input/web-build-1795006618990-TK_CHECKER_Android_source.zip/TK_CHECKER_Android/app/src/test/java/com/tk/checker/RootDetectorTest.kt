package com.tk.checker

import com.tk.checker.data.scanner.RootDetector
import com.tk.checker.domain.model.RootSignal
import com.tk.checker.domain.model.ScanStatus
import com.tk.checker.domain.model.SignalStrength
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RootDetectorTest {

    @Test
    fun singleWeakIndicator_neverFlagsDeviceAsRooted() {
        val signals = listOf(
            RootSignal("su_binary", "SU Binary", SignalStrength.STRONG, matched = false, accessible = true, "FS", "None"),
            RootSignal("root_managers", "Managers", SignalStrength.STRONG, matched = false, accessible = true, "PM", "None"),
            RootSignal("test_keys", "Test Keys", SignalStrength.WEAK, matched = true, accessible = true, "Build.TAGS", "test-keys present")
        )
        val result = RootDetector.evaluateSignals(signals, 1000L)
        assertFalse(result.isRooted)
        assertEquals(ScanStatus.WARNING, result.status)
    }

    @Test
    fun multipleStrongIndicators_confirmsRootDetected() {
        val signals = listOf(
            RootSignal("su_binary", "SU Binary", SignalStrength.STRONG, matched = true, accessible = true, "FS", "/system/xbin/su"),
            RootSignal("root_managers", "Managers", SignalStrength.STRONG, matched = true, accessible = true, "PM", "Magisk"),
            RootSignal("test_keys", "Test Keys", SignalStrength.WEAK, matched = false, accessible = true, "Build.TAGS", "release-keys")
        )
        val result = RootDetector.evaluateSignals(signals, 1000L)
        assertTrue(result.isRooted)
        assertEquals(ScanStatus.DETECTED, result.status)
        assertTrue(result.rootCommandAvailable)
    }

    @Test
    fun allAccessibleCleanSignals_returnsClean() {
        val signals = listOf(
            RootSignal("su_binary", "SU Binary", SignalStrength.STRONG, matched = false, accessible = true, "FS", "None"),
            RootSignal("root_managers", "Managers", SignalStrength.STRONG, matched = false, accessible = true, "PM", "None"),
            RootSignal("test_keys", "Test Keys", SignalStrength.WEAK, matched = false, accessible = true, "Build.TAGS", "release-keys")
        )
        val result = RootDetector.evaluateSignals(signals, 1000L)
        assertFalse(result.isRooted)
        assertEquals(ScanStatus.CLEAN, result.status)
    }

    @Test
    fun zeroAccessibleSignals_returnsUnavailableNeverClean() {
        val signals = listOf(
            RootSignal("proc_mounts", "Mounts", SignalStrength.MODERATE, matched = false, accessible = false, "/proc/mounts", "Blocked")
        )
        val result = RootDetector.evaluateSignals(signals, 1000L)
        assertFalse(result.isRooted)
        assertEquals(ScanStatus.UNAVAILABLE, result.status)
    }
}
