# TK CHECKER — Android Security & Gaming Diagnostics (`com.tk.checker`)

**TK CHECKER** is a native Kotlin + Jetpack Compose + Material 3 Android application (`minSdk 26`, `targetSdk 35`) designed for local device integrity inspection, universal injection & tampering detection, universal deleted application trace scanning, gaming hardware diagnostics, and Free Fire hardware compatibility analysis.

## Build & Install APK

### Option 1: Android Studio (Direct USB / Wireless Install)
1. Open this folder in **Android Studio Ladybug / Meerkat** or newer.
2. Let Gradle sync (`gradle-8.9`, AGP `8.7.2`, Kotlin `2.0.21`).
3. Connect your Android phone (Android 8.0+) with USB Debugging enabled and click **Run** (or **Build > Build Bundle(s) / APK(s) > Build APK(s)**).
4. Install `app/build/outputs/apk/debug/app-debug.apk` onto your Android phone.

### Option 2: Automated GitHub Actions APK Build (No Local SDK Required)
1. Create a GitHub repository and push this folder to its `main` branch.
2. Open the **Actions** tab → **Build TK CHECKER Android APK**. It runs on every push, or click **Run workflow**.
3. When the run is green, download from either place:
   - **Releases** page → latest `build-N` → `TK_CHECKER.apk`, `TK_CHECKER.apk.sha256`, and logs, or
   - the run's **Artifacts** → `tk-checker-debug-apk` and `tk-checker-build-logs`.
4. Verify integrity: `sha256sum -c TK_CHECKER.apk.sha256`.
5. Install on your phone (Android 8.0+): allow "Install unknown apps" for your browser/file manager, then open the APK.

The workflow generates the Gradle wrapper itself (`gradle-wrapper-files` artifact), runs the unit tests, and fails the
run if the APK is missing, lacks `classes.dex`/`AndroidManifest.xml`, has the wrong package, or fails `apksigner verify`.
The debug build is signed with the standard Android debug key, which is fine for sideloading but not for Play Store release.

### Gradle wrapper
`gradle/wrapper/gradle-wrapper.properties` is included, but the binary `gradle-wrapper.jar`, `gradlew` and `gradlew.bat`
are generated, not hand-written. To create them locally run `gradle wrapper --gradle-version 8.9` (Gradle 8.9+ installed),
or just download the `gradle-wrapper-files` artifact from a CI run. Android Studio does this automatically on first sync.

## Architecture & Key Modules
- `RootDetector.kt`: Multi-signal weighted root indicator verifier (never flags rooted from 1 weak signal).
- `RootDiagnosticsEngine.kt`: Strictly read-only `su -c` diagnostics requiring explicit user consent.
- `InjectionScanner.kt`: Universal inspection of `.so` native libraries, hooking frameworks, overlays, accessibility services, APK signatures, and shared-storage scripts.
- `TraceScanner.kt`: Universal deleted application trace detector across `Android/data`, `Android/obb`, shared storage APKs, `UsageStatsManager`, and optional authorized root package lists.
- `GamingDiagnosticsEngine.kt`: Real CPU, EGL GPU renderer, RAM, storage, refresh rate, battery, Android Thermal API, honest FPS status, and TCP latency/jitter/packet-loss probes.
- `FreeFireAnalyzer.kt`: Hardware/network readiness check with zero game modification or memory access.
- `ScanRepository.kt` & `ReportExporter.kt`: Local JSON history, scan comparison, and native `PdfDocument` / `.txt` export via `FileProvider`.

## Privacy Guarantee
No accounts, no ads, no analytics, no background uploads. All scan data stays strictly on your device.
